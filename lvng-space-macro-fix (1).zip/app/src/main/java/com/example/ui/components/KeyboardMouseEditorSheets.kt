package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isBackPressed
import androidx.compose.ui.input.pointer.isForwardPressed
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeyTriggerBehavior
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseNode
import com.example.model.KeymapActionType
import com.example.model.MouseTweaksConfig
import com.example.shizuku.LvngKeyCodes
import com.example.shizuku.LvngShizukuManager
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LvngCrimson
import com.example.ui.theme.LvngCrimsonBright
import com.example.ui.theme.LvngEmerald
import com.example.ui.theme.LvngTextPrimary
import com.example.ui.theme.LvngTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.roundToInt

/**
 * Translucent non-touchable runtime overlay displaying mapped Keyboard/Mouse badges
 * over the game screen. FPS Look remains invisible during gameplay, and no top lock banner is shown.
 */
@Composable
fun KeyboardMouseRuntimeHintsOverlay(
    config: KeyboardMouseConfig,
    @Suppress("UNUSED_PARAMETER") isAimCursorLocked: Boolean,
    modifier: Modifier = Modifier
) {
    if (!config.isActive || !config.tweaks.showKeyHintsOverlay || config.nodes.isEmpty()) return

    val alphaScale = config.tweaks.overlayOpacity.coerceIn(0.25f, 1.0f)
    val density = LocalDensity.current

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val minDim = minOf(widthPx, heightPx)

        config.nodes.forEach { node ->
            val cx = (node.xFraction * widthPx).roundToInt()
            val cy = (node.yFraction * heightPx).roundToInt()

            when (node.type) {
                KeymapActionType.WASD_JOYSTICK -> {
                    val radiusPx = (node.radiusFraction * minDim).roundToInt().coerceAtLeast(36)
                    val sizeDp = with(density) { (radiusPx * 2).toDp() }
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .offset { IntOffset(cx - radiusPx, cy - radiusPx) }
                            .size(sizeDp)
                            .alpha(alphaScale * 0.78f)
                            .clip(CircleShape)
                            .background(Color(0x24000000))
                            .border(1.2.dp, Color.White.copy(alpha = 0.55f), CircleShape)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = LvngKeyCodes.shortLabel(node.wasdUpKeyCode),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = LvngKeyCodes.shortLabel(node.wasdLeftKeyCode),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = LvngKeyCodes.shortLabel(node.wasdRightKeyCode),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = LvngKeyCodes.shortLabel(node.wasdDownKeyCode),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                KeymapActionType.MOUSE_AIM -> {
                    // FPS Look is invisible during gameplay; only visible inside keymapping editor
                    Unit
                }

                KeymapActionType.AIM_PAN -> {
                    val halfPx = with(density) { 22.dp.toPx() }.roundToInt()
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .offset { IntOffset(cx - halfPx, cy - halfPx) }
                            .size(44.dp)
                            .alpha(alphaScale * 0.90f)
                            .clip(CircleShape)
                            .background(Color(0x663A0B10))
                            .border(1.4.dp, LvngCrimsonBright, CircleShape)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.GpsFixed,
                                contentDescription = null,
                                tint = LvngCrimsonBright,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "LMB",
                                color = Color.White,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 8.sp
                            )
                        }
                    }
                }

                KeymapActionType.KEY_TAP -> {
                    val halfPx = with(density) { 18.dp.toPx() }.roundToInt()
                    val keyBadge = LvngKeyCodes.shortLabel(node.keyCode)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .offset { IntOffset(cx - halfPx, cy - halfPx) }
                            .size(36.dp)
                            .alpha(alphaScale)
                            .clip(CircleShape)
                            .background(Color(0x99120A0C))
                            .border(1.2.dp, LvngCrimsonBright.copy(alpha = 0.85f), CircleShape)
                    ) {
                        Text(
                            text = keyBadge,
                            color = Color.White,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 9.5.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KeyBindCaptureDialog(
    title: String,
    currentKeyCode: Int,
    onKeySelected: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    triggerBehavior: KeyTriggerBehavior? = null,
    onTriggerBehaviorChange: ((KeyTriggerBehavior) -> Unit)? = null
) {
    val focusRequester = remember { FocusRequester() }
    var isAssignListening by remember { mutableStateOf(false) }

    LaunchedEffect(isAssignListening) {
        if (!isAssignListening) return@LaunchedEffect
        runCatching { focusRequester.requestFocus() }
        val initialStatus = LvngShizukuManager.pollKeymapStatus()
        var lastEvdevSeq = initialStatus?.lastCapturedSeq ?: LvngShizukuManager.keymapStatus.value.lastCapturedSeq
        while (isActive && isAssignListening) {
            val status = LvngShizukuManager.pollKeymapStatus()
            if (status != null && status.lastCapturedSeq > lastEvdevSeq && status.lastCapturedKeyCode != 0) {
                lastEvdevSeq = status.lastCapturedSeq
                isAssignListening = false
                onKeySelected(status.lastCapturedKeyCode)
                break
            }
            delay(65L)
        }
    }

    val keyLabel = if (currentKeyCode == android.view.KeyEvent.KEYCODE_UNKNOWN || currentKeyCode == 0) {
        "Belum di-assign"
    } else {
        LvngKeyCodes.shortLabel(currentKeyCode)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xA6000000))
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { ev ->
                if (isAssignListening && ev.type == KeyEventType.KeyDown) {
                    val code = ev.nativeKeyEvent.keyCode
                    if (code != android.view.KeyEvent.KEYCODE_UNKNOWN &&
                        code != android.view.KeyEvent.KEYCODE_BACK
                    ) {
                        isAssignListening = false
                        onKeySelected(code)
                        return@onPreviewKeyEvent true
                    }
                }
                false
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(16.dp)
            .testTag("keybind_capture_dialog")
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 360.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xF5130A0D))
                .border(1.3.dp, LvngCrimsonBright.copy(alpha = 0.85f), RoundedCornerShape(18.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
                .pointerInput(isAssignListening) {
                    if (!isAssignListening) return@pointerInput
                    awaitPointerEventScope {
                        while (isAssignListening) {
                            val event = awaitPointerEvent()
                            when (event.type) {
                                PointerEventType.Scroll -> {
                                    val sy = event.changes.firstOrNull()?.scrollDelta?.y ?: 0f
                                    if (sy < 0f) {
                                        isAssignListening = false
                                        onKeySelected(LvngKeyCodes.MOUSE_SCROLL_UP)
                                    } else if (sy > 0f) {
                                        isAssignListening = false
                                        onKeySelected(LvngKeyCodes.MOUSE_SCROLL_DOWN)
                                    }
                                }
                                PointerEventType.Press -> {
                                    val isMouse = event.changes.any {
                                        it.type == androidx.compose.ui.input.pointer.PointerType.Mouse
                                    }
                                    if (isMouse) {
                                        val btns = event.buttons
                                        val mouseCode = when {
                                            btns.isSecondaryPressed -> LvngKeyCodes.MOUSE_RIGHT
                                            btns.isTertiaryPressed -> LvngKeyCodes.MOUSE_MIDDLE
                                            btns.isBackPressed -> LvngKeyCodes.MOUSE_SIDE_BACK
                                            btns.isForwardPressed -> LvngKeyCodes.MOUSE_SIDE_FORWARD
                                            btns.isPrimaryPressed -> LvngKeyCodes.MOUSE_LEFT
                                            else -> 0
                                        }
                                        if (mouseCode != 0) {
                                            isAssignListening = false
                                            onKeySelected(mouseCode)
                                        }
                                    }
                                }
                                else -> Unit
                            }
                        }
                    }
                }
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tombol saat ini: $keyLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = LvngTextSecondary
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            // Minimal Assign Row: Tap "Assign" -> turns RED -> press ANY key/mouse button freely
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isAssignListening) Color(0xFF330A10) else Color(0xFF211317))
                    .border(
                        width = if (isAssignListening) 1.8.dp else 1.1.dp,
                        color = if (isAssignListening) LvngCrimsonBright else Color(0xFF4B2B32),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable {
                        isAssignListening = !isAssignListening
                        if (isAssignListening) {
                            runCatching { focusRequester.requestFocus() }
                        }
                    }
                    .padding(horizontal = 14.dp)
                    .testTag("assign_trigger_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Assign",
                        color = if (isAssignListening) LvngCrimsonBright else Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = if (isAssignListening) {
                            "Tekan tombol Keyboard / Mouse bebas sekarang..."
                        } else {
                            "Ketuk Assign lalu tekan tombol bebas (saat ini: $keyLabel)"
                        },
                        color = if (isAssignListening) Color(0xFFFFB3BA) else LvngTextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (triggerBehavior != null && onTriggerBehaviorChange != null) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    KeyTriggerBehavior.entries.forEach { mode ->
                        val selected = triggerBehavior == mode
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selected) LvngCrimson.copy(alpha = 0.38f) else Color(0xFF1F171A))
                                .border(
                                    1.dp,
                                    if (selected) LvngCrimsonBright else Color(0xFF3A292E),
                                    RoundedCornerShape(9.dp)
                                )
                                .clickable { onTriggerBehaviorChange(mode) }
                        ) {
                            Text(
                                text = mode.label,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = LvngCrimson),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("keybind_done_button")
            ) {
                Text("Selesai", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Right-side drawer to inspect & fine-tune exact X / Y pixel coordinates, keybinds,
 * node label, trigger behavior, and radius for the selected node.
 */
@Composable
fun KeymapNodeSettingsDrawer(
    node: KeyboardMouseNode,
    screenWidthPx: Int,
    screenHeightPx: Int,
    onRequestBindKey: (wasdSlot: Int?, currentCode: Int) -> Unit,
    onUpdateNode: (KeyboardMouseNode) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var localName by remember(node.id) { mutableStateOf(node.name) }
    val safeW = screenWidthPx.coerceAtLeast(100)
    val safeH = screenHeightPx.coerceAtLeast(100)
    val curXPx = (node.xFraction * safeW).roundToInt()
    val curYPx = (node.yFraction * safeH).roundToInt()

    Column(
        modifier = modifier
            .fillMaxHeight()
            .widthIn(max = 315.dp)
            .fillMaxWidth(0.76f)
            .background(Color(0xF5120A0C))
            .border(1.dp, LvngCrimson.copy(alpha = 0.65f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {}
            )
            .padding(14.dp)
            .testTag("keymap_node_settings_drawer")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Pengaturan ${node.name}",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.Check, contentDescription = "Selesai", tint = LvngEmerald)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Node Name
            Text("Nama Tombol", style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
            BasicTextField(
                value = localName,
                onValueChange = { next ->
                    localName = next.take(12)
                    onUpdateNode(node.copy(name = localName))
                },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(LvngCrimsonBright),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF211619))
                    .border(1.dp, Color(0xFF45282E), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            )

            // Bound Key(s)
            when (node.type) {
                KeymapActionType.KEY_TAP -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF231317))
                            .border(1.dp, LvngCrimson.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .clickable { onRequestBindKey(null, node.keyCode) }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("node_drawer_rebind_button")
                    ) {
                        Column {
                            Text("Tombol Terkait", style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
                            Text(
                                text = LvngKeyCodes.shortLabel(node.keyCode),
                                fontFamily = JetBrainsMonoFontFamily,
                                color = LvngCrimsonBright,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                        Text(
                            text = "UBAH KEY",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(LvngCrimson)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    Text("Mode Input", style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        KeyTriggerBehavior.entries.forEach { mode ->
                            val selected = node.triggerBehavior == mode
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(if (selected) LvngCrimson.copy(alpha = 0.35f) else Color(0xFF1F171A))
                                    .border(
                                        1.dp,
                                        if (selected) LvngCrimsonBright else Color(0xFF3A292E),
                                        RoundedCornerShape(9.dp)
                                    )
                                    .clickable { onUpdateNode(node.copy(triggerBehavior = mode)) }
                            ) {
                                Text(
                                    text = mode.label,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    if (node.triggerBehavior == KeyTriggerBehavior.TAP_ONCE) {
                        DrawerFloatStepper(
                            label = "Durasi Tekan Tap",
                            valueDisplay = "${node.holdTapDurationMs} ms",
                            value = node.holdTapDurationMs.toFloat(),
                            range = 20f..150f,
                            step = 5f,
                            onValueChange = { v -> onUpdateNode(node.copy(holdTapDurationMs = v.roundToInt())) }
                        )
                    }
                }

                KeymapActionType.WASD_JOYSTICK -> {
                    Text("4 Arah Joystick", style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        WasdKeyPill("Atas", node.wasdUpKeyCode, Modifier.weight(1f)) {
                            onRequestBindKey(0, node.wasdUpKeyCode)
                        }
                        WasdKeyPill("Kiri", node.wasdLeftKeyCode, Modifier.weight(1f)) {
                            onRequestBindKey(1, node.wasdLeftKeyCode)
                        }
                        WasdKeyPill("Bawah", node.wasdDownKeyCode, Modifier.weight(1f)) {
                            onRequestBindKey(2, node.wasdDownKeyCode)
                        }
                        WasdKeyPill("Kanan", node.wasdRightKeyCode, Modifier.weight(1f)) {
                            onRequestBindKey(3, node.wasdRightKeyCode)
                        }
                    }

                    DrawerFloatStepper(
                        label = "Radius Analog Joystick",
                        valueDisplay = "${(node.radiusFraction * 100f).roundToInt()}%",
                        value = node.radiusFraction,
                        range = 0.05f..0.22f,
                        step = 0.005f,
                        onValueChange = { v -> onUpdateNode(node.copy(radiusFraction = v)) }
                    )
                }

                KeymapActionType.MOUSE_AIM -> {
                    Text(
                        text = "Pusat FPS Look Mouse. Gunakan panah X / Y di sekitar tombol Mouse untuk atur sensitivitas, atau tekan F1 untuk lock/bebas kursor.",
                        style = MaterialTheme.typography.labelSmall,
                        color = LvngTextSecondary
                    )
                }

                KeymapActionType.AIM_PAN -> {
                    Text(
                        text = "AimPan: letakkan tepat di tombol Tembak game. Klik Kiri Mouse (LMB) otomatis menekan posisi ini saat mode fokus aktif.",
                        style = MaterialTheme.typography.labelSmall,
                        color = LvngTextSecondary
                    )
                }
            }

            // Exact X coordinate control (Pixel & %)
            DrawerIntStepper(
                label = "Koordinat X",
                valueDisplay = "$curXPx px (${(node.xFraction * 100f).roundToInt()}%)",
                valuePx = curXPx,
                maxPx = safeW,
                onValuePxChange = { nextPx ->
                    onUpdateNode(node.copy(xFraction = (nextPx.toFloat() / safeW).coerceIn(0.02f, 0.98f)))
                },
                tag = "node_xy_slider_x"
            )

            // Exact Y coordinate control (Pixel & %)
            DrawerIntStepper(
                label = "Koordinat Y",
                valueDisplay = "$curYPx px (${(node.yFraction * 100f).roundToInt()}%)",
                valuePx = curYPx,
                maxPx = safeH,
                onValuePxChange = { nextPx ->
                    onUpdateNode(node.copy(yFraction = (nextPx.toFloat() / safeH).coerceIn(0.03f, 0.97f)))
                },
                tag = "node_xy_slider_y"
            )
        }
    }
}

@Composable
private fun WasdKeyPill(
    dir: String,
    keyCode: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF21171A))
            .border(1.dp, LvngCrimson.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
    ) {
        Text(dir, fontSize = 8.5.sp, color = LvngTextSecondary)
        Text(
            text = LvngKeyCodes.shortLabel(keyCode),
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

@Composable
fun MouseTweaksDrawer(
    tweaks: MouseTweaksConfig,
    inputSummary: String,
    onUpdateTweaks: (MouseTweaksConfig) -> Unit,
    onRequestBindToggleKey: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .widthIn(max = 335.dp)
            .fillMaxWidth(0.82f)
            .background(Color(0xF511090C))
            .border(1.dp, LvngCrimson.copy(alpha = 0.7f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {}
            )
            .padding(14.dp)
            .testTag("mouse_tweaks_drawer")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Tune, contentDescription = null, tint = LvngCrimsonBright, modifier = Modifier.size(18.dp))
                Text(
                    text = "Mouse & Keymap Tweaks",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.Check, contentDescription = "Selesai", tint = LvngEmerald)
            }
        }

        // Connected input devices diagnostic pill
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1D1216))
                .border(1.dp, Color(0xFF3E242B), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp)
        ) {
            Icon(Icons.Filled.Mouse, contentDescription = null, tint = LvngEmerald, modifier = Modifier.size(14.dp))
            Text(
                text = inputSummary.ifBlank { "Siap membaca Mouse / Keyboard via Shizuku" },
                style = MaterialTheme.typography.labelSmall,
                color = LvngTextPrimary,
                fontSize = 10.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Tuning Presets
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            TweakPresetChip("1:1 Raw") {
                onUpdateTweaks(tweaks.copy(sensitivityX = 1.0f, sensitivityY = 1.0f, acceleration = 0.0f, smoothing = 0.0f))
            }
            TweakPresetChip("FPS Snappy") {
                onUpdateTweaks(tweaks.copy(sensitivityX = 1.65f, sensitivityY = 1.45f, acceleration = 0.35f, smoothing = 0.12f))
            }
            TweakPresetChip("Smooth Aim") {
                onUpdateTweaks(tweaks.copy(sensitivityX = 1.25f, sensitivityY = 1.15f, acceleration = 0.15f, smoothing = 0.40f))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DrawerFloatStepper(
                label = "Sensitivitas X (Horizontal)",
                valueDisplay = String.format("%.2fx", tweaks.sensitivityX),
                value = tweaks.sensitivityX,
                range = 0.10f..10.00f,
                step = 0.10f,
                onValueChange = { onUpdateTweaks(tweaks.copy(sensitivityX = it)) }
            )
            DrawerFloatStepper(
                label = "Sensitivitas Y (Vertikal)",
                valueDisplay = String.format("%.2fx", tweaks.sensitivityY),
                value = tweaks.sensitivityY,
                range = 0.10f..10.00f,
                step = 0.10f,
                onValueChange = { onUpdateTweaks(tweaks.copy(sensitivityY = it)) }
            )
            DrawerFloatStepper(
                label = "Akselerasi Mouse",
                valueDisplay = String.format("%.2f", tweaks.acceleration),
                value = tweaks.acceleration,
                range = 0.0f..1.50f,
                step = 0.05f,
                onValueChange = { onUpdateTweaks(tweaks.copy(acceleration = it)) }
            )
            DrawerFloatStepper(
                label = "Aim Smoothing",
                valueDisplay = "${(tweaks.smoothing * 100f).roundToInt()}%",
                value = tweaks.smoothing,
                range = 0.0f..0.85f,
                step = 0.05f,
                onValueChange = { onUpdateTweaks(tweaks.copy(smoothing = it)) }
            )
            DrawerFloatStepper(
                label = "Deadzone Gerak Awal",
                valueDisplay = String.format("%.1f px", tweaks.deadzonePx),
                value = tweaks.deadzonePx,
                range = 0.0f..3.0f,
                step = 0.1f,
                onValueChange = { onUpdateTweaks(tweaks.copy(deadzonePx = it)) }
            )
            DrawerFloatStepper(
                label = "Batas Reset 360° Aim",
                valueDisplay = "${(tweaks.aimResetRadiusFraction * 100f).roundToInt()}%",
                value = tweaks.aimResetRadiusFraction,
                range = 0.12f..0.48f,
                step = 0.02f,
                onValueChange = { onUpdateTweaks(tweaks.copy(aimResetRadiusFraction = it)) }
            )

            // Cursor Lock Toggle Key row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF221518))
                    .border(1.dp, LvngCrimson.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                    .clickable(onClick = onRequestBindToggleKey)
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                Column {
                    Text("Tombol Lock / Bebas Aim", style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
                    Text(
                        text = LvngKeyCodes.shortLabel(tweaks.cursorToggleKeyCode),
                        fontFamily = JetBrainsMonoFontFamily,
                        color = LvngCrimsonBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = "GANTI",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(LvngCrimson)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            TweakSwitchRow("Invert Y Axis", tweaks.invertY) {
                onUpdateTweaks(tweaks.copy(invertY = it))
            }
            TweakSwitchRow("Auto-Lock Aim Saat Mulai", tweaks.autoLockAimOnEnable) {
                onUpdateTweaks(tweaks.copy(autoLockAimOnEnable = it))
            }
            TweakSwitchRow("Tampilkan Key Hints Di Game", tweaks.showKeyHintsOverlay) {
                onUpdateTweaks(tweaks.copy(showKeyHintsOverlay = it))
            }
            DrawerFloatStepper(
                label = "Transparansi Key Hints",
                valueDisplay = "${(tweaks.overlayOpacity * 100f).roundToInt()}%",
                value = tweaks.overlayOpacity,
                range = 0.25f..1.0f,
                step = 0.05f,
                onValueChange = { onUpdateTweaks(tweaks.copy(overlayOpacity = it)) }
            )
        }
    }
}

@Composable
private fun TweakPresetChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF28161B))
            .border(1.dp, LvngCrimson.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TweakSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1A1215))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = LvngTextPrimary, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = LvngCrimsonBright
            )
        )
    }
}

@Composable
private fun DrawerIntStepper(
    label: String,
    valueDisplay: String,
    valuePx: Int,
    maxPx: Int,
    onValuePxChange: (Int) -> Unit,
    tag: String = ""
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallStepIcon(Icons.Filled.Remove) { onValuePxChange((valuePx - 2).coerceIn(0, maxPx)) }
                Text(
                    text = valueDisplay,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = LvngCrimsonBright,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                SmallStepIcon(Icons.Filled.Add) { onValuePxChange((valuePx + 2).coerceIn(0, maxPx)) }
            }
        }
        Slider(
            value = valuePx.toFloat(),
            onValueChange = { onValuePxChange(it.roundToInt()) },
            valueRange = 0f..maxPx.toFloat().coerceAtLeast(10f),
            colors = SliderDefaults.colors(
                thumbColor = LvngCrimsonBright,
                activeTrackColor = LvngCrimson
            ),
            modifier = if (tag.isNotBlank()) Modifier.testTag(tag) else Modifier
        )
    }
}

@Composable
private fun DrawerFloatStepper(
    label: String,
    valueDisplay: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = LvngTextSecondary)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallStepIcon(Icons.Filled.Remove) {
                    onValueChange((value - step).coerceIn(range.start, range.endInclusive))
                }
                Text(
                    text = valueDisplay,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = LvngCrimsonBright,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                SmallStepIcon(Icons.Filled.Add) {
                    onValueChange((value + step).coerceIn(range.start, range.endInclusive))
                }
            }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = LvngCrimsonBright,
                activeTrackColor = LvngCrimson
            )
        )
    }
}

@Composable
private fun SmallStepIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(26.dp)
            .clip(CircleShape)
            .background(Color(0xFF28191D))
            .border(1.dp, LvngCrimson.copy(alpha = 0.55f), CircleShape)
            .clickable(onClick = onClick)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
    }
}
