package com.example.ui.components

import android.view.KeyEvent as AndroidKeyEvent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.input.LvngInputDeviceMonitor
import com.example.model.KeyTriggerBehavior
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseNode
import com.example.model.KeymapActionType
import com.example.shizuku.LvngKeyCodes
import com.example.shizuku.LvngShizukuManager
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LvngCrimson
import com.example.ui.theme.LvngCrimsonBright
import com.example.ui.theme.LvngCrimsonSoft
import com.example.ui.theme.LvngEmerald
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale
import kotlin.math.roundToInt

private sealed interface ActiveBindTarget {
    data class NodeKey(val nodeId: String, val wasdSlot: Int?) : ActiveBindTarget
    data object CursorToggleKey : ActiveBindTarget
}

@Composable
fun KeyboardMouseKeymapEditor(
    config: KeyboardMouseConfig,
    onUpdateConfig: (KeyboardMouseConfig) -> Unit,
    onSave: (KeyboardMouseConfig) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keymapLive by LvngShizukuManager.keymapStatus.collectAsState()
    val hardwareSnap by LvngInputDeviceMonitor.snapshot.collectAsState()

    var isAddMenuOpen by remember { mutableStateOf(false) }
    var selectedNodeId by remember { mutableStateOf(config.nodes.firstOrNull()?.id) }
    var showNodeDrawer by remember { mutableStateOf(false) }
    var showTweaksDrawer by remember { mutableStateOf(false) }
    var bindTarget by remember { mutableStateOf<ActiveBindTarget?>(null) }

    val latestConfig by rememberUpdatedState(config)
    val latestOnUpdate by rememberUpdatedState(onUpdateConfig)

    LaunchedEffect(Unit) {
        LvngInputDeviceMonitor.init(context)
        while (isActive) {
            LvngInputDeviceMonitor.refresh(context)
            LvngShizukuManager.pollKeymapStatus()
            delay(1_100L)
        }
    }

    val selectedNode = config.nodes.firstOrNull { it.id == selectedNodeId }
    val needBridge = hardwareSnap.hasKeyboard && !keymapLive.hasEvdevKeyboard && !hardwareSnap.isBridgeActive
    val hwLabel = if (hardwareSnap.hasKeyboard || hardwareSnap.hasMouse) {
        hardwareSnap.summaryLabel()
    } else {
        keymapLive.inputSummary
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0x6E000000))
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown && ev.nativeKeyEvent.keyCode == AndroidKeyEvent.KEYCODE_BACK) {
                    if (bindTarget != null) {
                        bindTarget = null
                    } else if (showNodeDrawer || showTweaksDrawer) {
                        showNodeDrawer = false
                        showTweaksDrawer = false
                    } else {
                        onCancel()
                    }
                    true
                } else {
                    false
                }
            }
            .testTag("keyboard_mouse_keymap_editor")
    ) {
        val screenW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val screenH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val minDim = minOf(screenW, screenH)
        val density = LocalDensity.current

        val selectedOffset: Offset? = selectedNode?.let {
            Offset(it.xFraction * screenW, it.yFraction * screenH)
        }

        // Background alignment crosshair + tap empty area closes "+" menu
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    isAddMenuOpen = false
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                selectedOffset?.let { pos ->
                    val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.48f),
                        start = Offset(0f, pos.y),
                        end = Offset(size.width, pos.y),
                        strokeWidth = 1.5f,
                        pathEffect = dash
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.48f),
                        start = Offset(pos.x, 0f),
                        end = Offset(pos.x, size.height),
                        strokeWidth = 1.5f,
                        pathEffect = dash
                    )
                }
            }
        }

        // Layer 1: Draggable Widgets on Canvas
        val sortedNodes = remember(config.nodes) {
            config.nodes.sortedBy {
                when (it.type) {
                    KeymapActionType.WASD_JOYSTICK -> 0
                    KeymapActionType.MOUSE_AIM -> 1
                    KeymapActionType.AIM_PAN -> 2
                    KeymapActionType.KEY_TAP -> 3
                }
            }
        }

        sortedNodes.forEach { node ->
            val isSelected = node.id == selectedNodeId
            val cx = (node.xFraction * screenW).roundToInt()
            val cy = (node.yFraction * screenH).roundToInt()

            val updateNodePosition: (Float, Float) -> Unit = { nextXFrac, nextYFrac ->
                val cur = latestConfig
                latestOnUpdate(
                    cur.copy(
                        nodes = cur.nodes.map { item ->
                            if (item.id == node.id) {
                                item.copy(
                                    xFraction = nextXFrac.coerceIn(0.03f, 0.97f),
                                    yFraction = nextYFrac.coerceIn(0.05f, 0.95f)
                                )
                            } else item
                        }
                    )
                )
            }

            when (node.type) {
                KeymapActionType.WASD_JOYSTICK -> {
                    val radiusPx = (node.radiusFraction * minDim).roundToInt().coerceAtLeast(46)
                    val diameterDp = with(density) { (radiusPx * 2).toDp() }
                    DraggableNodeBadge(
                        node = node,
                        screenW = screenW,
                        screenH = screenH,
                        onSelect = { selectedNodeId = node.id },
                        onDragTo = updateNodePosition,
                        modifier = Modifier
                            .offset { IntOffset(cx - radiusPx, cy - radiusPx) }
                            .size(diameterDp)
                            .clip(CircleShape)
                            .background(if (isSelected) LvngCrimson.copy(alpha = 0.24f) else Color(0x33000000))
                            .border(
                                width = if (isSelected) 2.2.dp else 1.5.dp,
                                color = if (isSelected) LvngCrimsonBright else Color.White.copy(alpha = 0.85f),
                                shape = CircleShape
                            )
                            .testTag("km_node_${node.id}")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(LvngKeyCodes.shortLabel(node.wasdUpKeyCode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text(LvngKeyCodes.shortLabel(node.wasdLeftKeyCode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(LvngKeyCodes.shortLabel(node.wasdRightKeyCode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Text(LvngKeyCodes.shortLabel(node.wasdDownKeyCode), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }

                KeymapActionType.MOUSE_AIM -> {
                    // FPS Look widget: [▲ / X / ▼]  [Center Draggable Mouse Icon]  [▲ / Y / ▼]
                    val widgetW = 172.dp
                    val widgetH = 98.dp
                    val halfWPx = with(density) { (widgetW / 2).toPx().roundToInt() }
                    val halfHPx = with(density) { (widgetH / 2).toPx().roundToInt() }
                    val lockBadge = LvngKeyCodes.shortLabel(config.tweaks.cursorToggleKeyCode)

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .offset { IntOffset(cx - halfWPx, cy - halfHPx) }
                            .width(widgetW)
                            .height(widgetH)
                            .testTag("km_node_${node.id}")
                    ) {
                        // Left: X Sensitivity with Up/Down Arrows
                        SensitivityAxisStepper(
                            axisLabel = "X",
                            value = config.tweaks.sensitivityX,
                            accentColor = LvngEmerald,
                            onIncrease = {
                                val cur = latestConfig
                                val next = (cur.tweaks.sensitivityX + 0.10f).coerceIn(0.10f, 10.00f)
                                latestOnUpdate(cur.copy(tweaks = cur.tweaks.copy(sensitivityX = next)))
                            },
                            onDecrease = {
                                val cur = latestConfig
                                val next = (cur.tweaks.sensitivityX - 0.10f).coerceIn(0.10f, 10.00f)
                                latestOnUpdate(cur.copy(tweaks = cur.tweaks.copy(sensitivityX = next)))
                            },
                            tagPrefix = "fps_sens_x"
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Center: Draggable Compact Mouse Badge
                        DraggableNodeBadge(
                            node = node,
                            screenW = screenW,
                            screenH = screenH,
                            onSelect = { selectedNodeId = node.id },
                            onDragTo = updateNodePosition,
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) Color(0xCC11362C) else Color(0xB80E1E1B))
                                .border(
                                    width = if (isSelected) 2.4.dp else 1.6.dp,
                                    color = if (isSelected) LvngEmerald else LvngEmerald.copy(alpha = 0.85f),
                                    shape = CircleShape
                                )
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Filled.Mouse,
                                    contentDescription = "FPS Look",
                                    tint = LvngEmerald,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = lockBadge,
                                    color = Color.White,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 8.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Right: Y Sensitivity with Up/Down Arrows
                        SensitivityAxisStepper(
                            axisLabel = "Y",
                            value = config.tweaks.sensitivityY,
                            accentColor = Color(0xFF4DD0E1),
                            onIncrease = {
                                val cur = latestConfig
                                val next = (cur.tweaks.sensitivityY + 0.10f).coerceIn(0.10f, 10.00f)
                                latestOnUpdate(cur.copy(tweaks = cur.tweaks.copy(sensitivityY = next)))
                            },
                            onDecrease = {
                                val cur = latestConfig
                                val next = (cur.tweaks.sensitivityY - 0.10f).coerceIn(0.10f, 10.00f)
                                latestOnUpdate(cur.copy(tweaks = cur.tweaks.copy(sensitivityY = next)))
                            },
                            tagPrefix = "fps_sens_y"
                        )
                    }
                }

                KeymapActionType.AIM_PAN -> {
                    val halfPx = with(density) { 28.dp.toPx() }.roundToInt()
                    DraggableNodeBadge(
                        node = node,
                        screenW = screenW,
                        screenH = screenH,
                        onSelect = { selectedNodeId = node.id },
                        onDragTo = updateNodePosition,
                        modifier = Modifier
                            .offset { IntOffset(cx - halfPx, cy - halfPx) }
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color(0xCC4D0D15) else Color(0x9E260A0E))
                            .border(
                                width = if (isSelected) 2.4.dp else 1.7.dp,
                                color = if (isSelected) Color(0xFFFF7043) else LvngCrimsonBright,
                                shape = CircleShape
                            )
                            .testTag("km_node_${node.id}")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.GpsFixed,
                                contentDescription = "AimPan Tembak",
                                tint = Color(0xFFFF8A65),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "AimPan",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 8.5.sp,
                                maxLines = 1
                            )
                            Text(
                                text = "LMB",
                                color = LvngCrimsonSoft,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 7.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                KeymapActionType.KEY_TAP -> {
                    val halfPx = with(density) { 26.dp.toPx() }.roundToInt()
                    DraggableNodeBadge(
                        node = node,
                        screenW = screenW,
                        screenH = screenH,
                        onSelect = { selectedNodeId = node.id },
                        onDragTo = updateNodePosition,
                        modifier = Modifier
                            .offset { IntOffset(cx - halfPx, cy - halfPx) }
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) LvngCrimson.copy(alpha = 0.42f) else Color(0x66140A0C))
                            .border(
                                width = if (isSelected) 2.4.dp else 1.5.dp,
                                color = if (isSelected) LvngCrimsonBright else Color.White.copy(alpha = 0.88f),
                                shape = CircleShape
                            )
                            .testTag("km_node_${node.id}")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = LvngKeyCodes.shortLabel(node.keyCode),
                                fontFamily = JetBrainsMonoFontFamily,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                            Text(
                                text = "Sentuh",
                                color = Color.White.copy(alpha = 0.78f),
                                fontSize = 7.5.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Layer 2: Top-Center 3-Button Floating Bar (+, -, Centang) + Expandable 4-Feature Bar
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 10.dp, start = 12.dp, end = 12.dp)
        ) {
            // 3 Primary Top-Center Buttons: +  -  ✓
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xEB150A0D))
                    .border(1.2.dp, LvngCrimson.copy(alpha = 0.75f), RoundedCornerShape(18.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                TopBarCircleAction(
                    icon = Icons.Filled.Add,
                    description = "Tambah Fitur Keymap",
                    tint = Color.White,
                    containerColor = if (isAddMenuOpen) LvngCrimson else Color(0xFF281418),
                    borderColor = if (isAddMenuOpen) LvngCrimsonBright else LvngCrimson.copy(alpha = 0.6f),
                    tag = "keymap_add_menu_button"
                ) {
                    isAddMenuOpen = !isAddMenuOpen
                }

                TopBarCircleAction(
                    icon = Icons.Filled.Remove,
                    description = "Hapus Item Terpilih",
                    tint = if (selectedNode != null) Color(0xFFFF8A80) else Color(0x66FFFFFF),
                    containerColor = Color(0xFF281418),
                    borderColor = if (selectedNode != null) LvngCrimson.copy(alpha = 0.65f) else Color(0x33FFFFFF),
                    tag = "keymap_delete_node_button"
                ) {
                    if (selectedNode != null) {
                        val remaining = config.nodes.filterNot { it.id == selectedNode.id }
                        onUpdateConfig(config.copy(nodes = remaining))
                        selectedNodeId = remaining.firstOrNull()?.id
                        showNodeDrawer = false
                    }
                }

                TopBarCircleAction(
                    icon = Icons.Filled.Check,
                    description = "Simpan Keymap",
                    tint = LvngEmerald,
                    containerColor = Color(0xFF102A21),
                    borderColor = LvngEmerald.copy(alpha = 0.85f),
                    tag = "keymap_save_button"
                ) {
                    onSave(config.copy(isActive = config.nodes.isNotEmpty()))
                }
            }

            // Expandable 4 Feature Buttons underneath (+): Joystick, FPS Look, AimPan, Sentuh
            AnimatedVisibility(
                visible = isAddMenuOpen,
                enter = fadeIn(tween(150)) + expandVertically(tween(180)),
                exit = fadeOut(tween(120)) + shrinkVertically(tween(150))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xF0140A0C))
                        .border(1.1.dp, LvngCrimson.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    FeatureAddChip(
                        icon = Icons.Filled.Gamepad,
                        label = "Joystick",
                        accent = Color.White,
                        tag = "keymap_feature_joystick"
                    ) {
                        isAddMenuOpen = false
                        val existing = config.nodes.firstOrNull { it.type == KeymapActionType.WASD_JOYSTICK }
                        if (existing != null) {
                            selectedNodeId = existing.id
                        } else {
                            val wasd = KeyboardMouseNode(
                                id = "kb_wasd",
                                name = "Joystick",
                                type = KeymapActionType.WASD_JOYSTICK,
                                keyCode = 0,
                                xFraction = 0.20f,
                                yFraction = 0.70f,
                                radiusFraction = 0.10f
                            )
                            onUpdateConfig(config.copy(nodes = config.nodes + wasd))
                            selectedNodeId = wasd.id
                        }
                    }

                    FeatureAddChip(
                        icon = Icons.Filled.Mouse,
                        label = "FPS Look",
                        accent = LvngEmerald,
                        tag = "keymap_feature_fps_look"
                    ) {
                        isAddMenuOpen = false
                        val existing = config.nodes.firstOrNull { it.type == KeymapActionType.MOUSE_AIM }
                        if (existing != null) {
                            selectedNodeId = existing.id
                        } else {
                            val aim = KeyboardMouseNode(
                                id = "mouse_aim",
                                name = "FPS Look",
                                type = KeymapActionType.MOUSE_AIM,
                                keyCode = 0,
                                xFraction = 0.62f,
                                yFraction = 0.46f,
                                radiusFraction = 0.12f
                            )
                            onUpdateConfig(config.copy(nodes = config.nodes + aim))
                            selectedNodeId = aim.id
                        }
                    }

                    FeatureAddChip(
                        icon = Icons.Filled.GpsFixed,
                        label = "AimPan",
                        accent = Color(0xFFFF8A65),
                        tag = "keymap_feature_aim_pan"
                    ) {
                        isAddMenuOpen = false
                        val existing = config.nodes.firstOrNull { it.type == KeymapActionType.AIM_PAN }
                        if (existing != null) {
                            selectedNodeId = existing.id
                        } else {
                            val aimPan = KeyboardMouseNode(
                                id = "aim_pan_fire",
                                name = "AimPan",
                                type = KeymapActionType.AIM_PAN,
                                keyCode = LvngKeyCodes.MOUSE_LEFT,
                                xFraction = 0.85f,
                                yFraction = 0.72f,
                                triggerBehavior = KeyTriggerBehavior.HOLD
                            )
                            onUpdateConfig(config.copy(nodes = config.nodes + aimPan))
                            selectedNodeId = aimPan.id
                        }
                    }

                    FeatureAddChip(
                        icon = Icons.Filled.TouchApp,
                        label = "Sentuh",
                        accent = LvngCrimsonBright,
                        tag = "keymap_feature_sentuh"
                    ) {
                        isAddMenuOpen = false
                        val idx = config.nodes.count { it.type == KeymapActionType.KEY_TAP } + 1
                        val newId = "kb_sentuh_${System.currentTimeMillis()}_$idx"
                        val node = KeyboardMouseNode(
                            id = newId,
                            name = "Sentuh $idx",
                            type = KeymapActionType.KEY_TAP,
                            keyCode = AndroidKeyEvent.KEYCODE_UNKNOWN,
                            xFraction = (0.48f + ((idx % 4) * 0.06f)).coerceIn(0.18f, 0.88f),
                            yFraction = (0.54f + ((idx % 3) * 0.06f)).coerceIn(0.22f, 0.85f),
                            triggerBehavior = KeyTriggerBehavior.HOLD
                        )
                        onUpdateConfig(config.copy(nodes = config.nodes + node))
                        selectedNodeId = newId
                    }
                }
            }

            // OTG / Bluetooth Hardware Status + Trigger Quick Bar (when needed or selected)
            if (hwLabel.isNotBlank()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (needBridge) Color(0xD9382107) else Color(0xB80E0A0B))
                        .border(
                            1.dp,
                            if (needBridge) Color(0xFFFFB74D) else Color(0x44FFFFFF),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable(enabled = needBridge) {
                            LvngInputDeviceMonitor.openAccessibilitySettings(context)
                        }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Keyboard,
                        contentDescription = null,
                        tint = if (needBridge) Color(0xFFFFB74D) else LvngEmerald,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = if (needBridge) {
                            "${hardwareSnap.keyboards.firstOrNull().orEmpty()} terdeteksi • Tap aktifkan Bridge"
                        } else {
                            hwLabel
                        },
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Layer 3: Compact Bottom Action Pill ONLY for Contextual Selected Item Settings (Trigger / Tweaks)
        if (selectedNode != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xE8140A0D))
                    .border(1.dp, LvngCrimson.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                when (selectedNode.type) {
                    KeymapActionType.KEY_TAP -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(9.dp))
                                .background(Color(0xFF3A1217))
                                .clickable {
                                    bindTarget = ActiveBindTarget.NodeKey(selectedNode.id, wasdSlot = null)
                                }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                                .testTag("sentuh_setting_button")
                        ) {
                            Icon(Icons.Filled.Tune, contentDescription = null, tint = LvngCrimsonBright, modifier = Modifier.size(15.dp))
                            Text(
                                text = "Setting (${LvngKeyCodes.shortLabel(selectedNode.keyCode)})",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                    }

                    KeymapActionType.WASD_JOYSTICK -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SmallCircleBtn(Icons.Filled.Remove) {
                                onUpdateConfig(
                                    config.copy(
                                        nodes = config.nodes.map {
                                            if (it.id == selectedNode.id) {
                                                it.copy(radiusFraction = (it.radiusFraction - 0.01f).coerceIn(0.05f, 0.22f))
                                            } else it
                                        }
                                    )
                                )
                            }
                            Text(
                                text = "Ukuran Joystick ${(selectedNode.radiusFraction * 100f).roundToInt()}%",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            SmallCircleBtn(Icons.Filled.Add) {
                                onUpdateConfig(
                                    config.copy(
                                        nodes = config.nodes.map {
                                            if (it.id == selectedNode.id) {
                                                it.copy(radiusFraction = (it.radiusFraction + 0.01f).coerceIn(0.05f, 0.22f))
                                            } else it
                                        }
                                    )
                                )
                            }
                        }
                    }

                    KeymapActionType.MOUSE_AIM -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(9.dp))
                                .background(Color(0xFF102A21))
                                .clickable {
                                    showNodeDrawer = false
                                    showTweaksDrawer = !showTweaksDrawer
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Filled.Tune, contentDescription = null, tint = LvngEmerald, modifier = Modifier.size(15.dp))
                            Text(
                                text = "Tweaks FPS Look • Lock [${LvngKeyCodes.shortLabel(config.tweaks.cursorToggleKeyCode)}]",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    KeymapActionType.AIM_PAN -> {
                        Text(
                            text = "AimPan: Klik Kiri Mouse (LMB) tembak di target ini",
                            color = Color(0xFFFFAB91),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }

                SmallCircleBtn(Icons.Filled.Settings) {
                    showTweaksDrawer = false
                    showNodeDrawer = !showNodeDrawer
                }
            }
        }

        // Layer 4a: Node Settings Drawer
        AnimatedVisibility(
            visible = showNodeDrawer && selectedNode != null,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(tween(180)),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(tween(150)),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            if (selectedNode != null) {
                KeymapNodeSettingsDrawer(
                    node = selectedNode,
                    screenWidthPx = screenW.roundToInt(),
                    screenHeightPx = screenH.roundToInt(),
                    onRequestBindKey = { wasdSlot, _ ->
                        bindTarget = ActiveBindTarget.NodeKey(selectedNode.id, wasdSlot)
                    },
                    onUpdateNode = { updated ->
                        onUpdateConfig(
                            config.copy(nodes = config.nodes.map { if (it.id == updated.id) updated else it })
                        )
                    },
                    onClose = { showNodeDrawer = false }
                )
            }
        }

        // Layer 4b: Mouse Tweaks Drawer
        AnimatedVisibility(
            visible = showTweaksDrawer,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(tween(180)),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(tween(150)),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            MouseTweaksDrawer(
                tweaks = config.tweaks,
                inputSummary = hwLabel,
                onUpdateTweaks = { nextTweaks -> onUpdateConfig(config.copy(tweaks = nextTweaks)) },
                onRequestBindToggleKey = { bindTarget = ActiveBindTarget.CursorToggleKey },
                onClose = { showTweaksDrawer = false }
            )
        }

        // Layer 5: Trigger Setting & Key Capture Dialog
        bindTarget?.let { target ->
            val (title, currentCode, triggerMode, onTriggerMode) = when (target) {
                is ActiveBindTarget.CursorToggleKey ->
                    Quad(
                        "Tombol Lock / Bebas Kursor",
                        config.tweaks.cursorToggleKeyCode,
                        null,
                        null
                    )
                is ActiveBindTarget.NodeKey -> {
                    val n = config.nodes.firstOrNull { it.id == target.nodeId }
                    val c = when (target.wasdSlot) {
                        0 -> n?.wasdUpKeyCode ?: AndroidKeyEvent.KEYCODE_W
                        1 -> n?.wasdLeftKeyCode ?: AndroidKeyEvent.KEYCODE_A
                        2 -> n?.wasdDownKeyCode ?: AndroidKeyEvent.KEYCODE_S
                        3 -> n?.wasdRightKeyCode ?: AndroidKeyEvent.KEYCODE_D
                        else -> n?.keyCode ?: AndroidKeyEvent.KEYCODE_F
                    }
                    val mode = if (target.wasdSlot == null && n?.type == KeymapActionType.KEY_TAP) n.triggerBehavior else null
                    val modeCb: ((KeyTriggerBehavior) -> Unit)? = if (mode != null) {
                        { newMode ->
                            onUpdateConfig(
                                config.copy(
                                    nodes = config.nodes.map { item ->
                                        if (item.id == target.nodeId) item.copy(triggerBehavior = newMode) else item
                                    }
                                )
                            )
                        }
                    } else null
                    Quad("Setting ${n?.name ?: "Sentuh"}", c, mode, modeCb)
                }
            }
            KeyBindCaptureDialog(
                title = title,
                currentKeyCode = currentCode,
                triggerBehavior = triggerMode,
                onTriggerBehaviorChange = onTriggerMode,
                onKeySelected = { chosenCode ->
                    when (target) {
                        is ActiveBindTarget.CursorToggleKey -> {
                            onUpdateConfig(
                                config.copy(tweaks = config.tweaks.copy(cursorToggleKeyCode = chosenCode))
                            )
                        }
                        is ActiveBindTarget.NodeKey -> {
                            onUpdateConfig(
                                config.copy(
                                    nodes = config.nodes.map { n ->
                                        if (n.id != target.nodeId) n
                                        else when (target.wasdSlot) {
                                            0 -> n.copy(wasdUpKeyCode = chosenCode)
                                            1 -> n.copy(wasdLeftKeyCode = chosenCode)
                                            2 -> n.copy(wasdDownKeyCode = chosenCode)
                                            3 -> n.copy(wasdRightKeyCode = chosenCode)
                                            else -> n.copy(keyCode = chosenCode)
                                        }
                                    }
                                )
                            )
                        }
                    }
                },
                onDismiss = { bindTarget = null }
            )
        }
    }
}

private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

@Composable
private fun DraggableNodeBadge(
    node: KeyboardMouseNode,
    screenW: Float,
    screenH: Float,
    onSelect: () -> Unit,
    onDragTo: (Float, Float) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val latestNode by rememberUpdatedState(node)
    val latestOnSelect by rememberUpdatedState(onSelect)
    val latestOnDragTo by rememberUpdatedState(onDragTo)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .pointerInput(node.id, screenW, screenH) {
                detectDragGestures(
                    onDragStart = { latestOnSelect() },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val cur = latestNode
                        latestOnDragTo(
                            cur.xFraction + dragAmount.x / screenW,
                            cur.yFraction + dragAmount.y / screenH
                        )
                    }
                )
            }
            .clickable { onSelect() }
    ) {
        content()
    }
}

@Composable
private fun SensitivityAxisStepper(
    axisLabel: String,
    value: Float,
    accentColor: Color,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    tagPrefix: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.width(48.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xD9161013))
                .border(1.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                .clickable(onClick = onIncrease)
                .testTag("${tagPrefix}_up")
        ) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowUp,
                contentDescription = "Tambah $axisLabel",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xD9120B0E))
                .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(7.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = axisLabel,
                color = accentColor,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp
            )
            Text(
                text = String.format(Locale.US, "%.1f", value),
                color = Color.White,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 9.5.sp
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xD9161013))
                .border(1.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                .clickable(onClick = onDecrease)
                .testTag("${tagPrefix}_down")
        ) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = "Kurangi $axisLabel",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun TopBarCircleAction(
    icon: ImageVector,
    description: String,
    tint: Color,
    containerColor: Color,
    borderColor: Color,
    tag: String,
    onClick: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(containerColor)
            .border(1.2.dp, borderColor, CircleShape)
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun FeatureAddChip(
    icon: ImageVector,
    label: String,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF231217))
            .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag(tag)
    ) {
        Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(18.dp))
        Text(
            text = label,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun SmallCircleBtn(icon: ImageVector, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color(0xFF28161B))
            .border(1.dp, LvngCrimson.copy(alpha = 0.55f), CircleShape)
            .clickable(onClick = onClick)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
    }
}
