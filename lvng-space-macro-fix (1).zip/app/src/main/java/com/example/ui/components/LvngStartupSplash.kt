package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LvngCrimson
import com.example.ui.theme.LvngCrimsonBright
import com.example.ui.theme.LvngCyan
import com.example.ui.theme.LvngEmerald
import com.example.ui.theme.LvngTextPrimary
import com.example.ui.theme.LvngTextSecondary
import com.example.ui.theme.LvngVoid
import com.example.ui.theme.RajdhaniFontFamily
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LvngStartupSplashOverlay(
    visible: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val emblemScale = remember { Animatable(0.58f) }
    val emblemAlpha = remember { Animatable(0f) }
    val textSlideY = remember { Animatable(24f) }
    val textAlpha = remember { Animatable(0f) }
    val pulseRadius = remember { Animatable(0f) }
    val bootProgress = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "lvng_splash_rings")
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rot"
    )

    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        coroutineScope {
            launch {
                emblemAlpha.animateTo(1f, tween(340, easing = FastOutSlowInEasing))
            }
            launch {
                emblemScale.animateTo(1.06f, tween(460, easing = FastOutSlowInEasing))
                emblemScale.animateTo(1.0f, tween(220, easing = FastOutSlowInEasing))
            }
            launch {
                pulseRadius.animateTo(1f, tween(850, easing = FastOutSlowInEasing))
            }
            launch {
                delay(180L)
                launch { textAlpha.animateTo(1f, tween(360)) }
                launch { textSlideY.animateTo(0f, tween(420, easing = FastOutSlowInEasing)) }
            }
            launch {
                bootProgress.animateTo(1f, tween(1450, easing = FastOutSlowInEasing))
            }
        }
        delay(220L)
        onFinished()
    }

    AnimatedVisibility(
        visible = visible,
        exit = fadeOut(tween(340)) + scaleOut(targetScale = 1.07f, animationSpec = tween(340)),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF28080D),
                            Color(0xFF120709),
                            LvngVoid
                        )
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onFinished
                )
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("lvng_startup_splash")
        ) {
            // Subtle tactical HUD grid + shockwave radar pulse + dual rotating reticle rings
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width * 0.5f
                val cy = size.height * 0.44f
                val gridStep = 44.dp.toPx()

                var gx = cx % gridStep
                while (gx < size.width) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.03f),
                        start = Offset(gx, 0f),
                        end = Offset(gx, size.height),
                        strokeWidth = 1f
                    )
                    gx += gridStep
                }
                var gy = cy % gridStep
                while (gy < size.height) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.03f),
                        start = Offset(0f, gy),
                        end = Offset(size.width, gy),
                        strokeWidth = 1f
                    )
                    gy += gridStep
                }

                // Expanding sonar ring at launch
                val shockR = 40.dp.toPx() + pulseRadius.value * (size.minDimension * 0.42f)
                val shockAlpha = (1f - pulseRadius.value).coerceIn(0f, 1f) * 0.48f
                if (shockAlpha > 0.01f) {
                    drawCircle(
                        color = LvngCrimsonBright.copy(alpha = shockAlpha),
                        radius = shockR,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }

                // Outer counter-rotating targeting arc
                val ringOuterR = 82.dp.toPx() * emblemScale.value
                rotate(degrees = outerRotation, pivot = Offset(cx, cy)) {
                    for (idx in 0 until 3) {
                        drawArc(
                            color = LvngCrimsonBright.copy(alpha = 0.85f * emblemAlpha.value),
                            startAngle = idx * 120f + 10f,
                            sweepAngle = 76f,
                            useCenter = false,
                            topLeft = Offset(cx - ringOuterR, cy - ringOuterR),
                            size = Size(ringOuterR * 2f, ringOuterR * 2f),
                            style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }

                // Inner precision cyan + emerald HUD ring
                val ringInnerR = 64.dp.toPx() * emblemScale.value
                rotate(degrees = innerRotation, pivot = Offset(cx, cy)) {
                    for (idx in 0 until 4) {
                        val arcColor = if (idx % 2 == 0) LvngCyan else LvngCrimsonSoftAccent
                        drawArc(
                            color = arcColor.copy(alpha = 0.72f * emblemAlpha.value),
                            startAngle = idx * 90f + 16f,
                            sweepAngle = 44f,
                            useCenter = false,
                            topLeft = Offset(cx - ringInnerR, cy - ringInnerR),
                            size = Size(ringInnerR * 2f, ringInnerR * 2f),
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }

            // Centerpiece Emblem & Typography
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 28.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .scale(emblemScale.value)
                        .alpha(emblemAlpha.value)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF450B13),
                                    Color(0xFF1A080C)
                                )
                            )
                        )
                        .border(1.8.dp, LvngCrimsonBright.copy(alpha = 0.9f), CircleShape)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "LVNG",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            letterSpacing = 3.sp,
                            color = Color.White
                        )
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(2.5.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(LvngCrimsonBright, LvngCyan)
                                    )
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(34.dp))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .alpha(textAlpha.value)
                        .padding(top = textSlideY.value.coerceAtLeast(0f).dp)
                ) {
                    Text(
                        text = "LVNG SPACE",
                        style = TextStyle(
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 36.sp,
                            letterSpacing = 5.sp,
                            brush = Brush.horizontalGradient(
                                listOf(LvngTextPrimary, Color.White, Color(0xFFFF8A8A))
                            )
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xCC180E11))
                            .border(1.dp, LvngCrimson.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(LvngEmerald)
                        )
                        Text(
                            text = "PRO KEYMAP & MACRO ENGINE",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            letterSpacing = 1.1.sp,
                            color = LvngTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(26.dp))

                    // Sleek laser boot bar
                    Box(
                        modifier = Modifier
                            .width(190.dp)
                            .height(3.5.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFF23181B))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(bootProgress.value.coerceIn(0f, 1f))
                                .height(3.5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(LvngCrimson, LvngCrimsonBright, LvngCyan)
                                    )
                                )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "INITIALIZING MOBILADOR INPUT PIPELINE...",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 9.5.sp,
                        letterSpacing = 0.8.sp,
                        color = LvngTextSecondary
                    )
                }
            }
        }
    }
}

private val LvngCrimsonSoftAccent = Color(0xFFFF7A7A)
