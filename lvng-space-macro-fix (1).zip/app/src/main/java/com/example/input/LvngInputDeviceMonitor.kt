package com.example.input

import android.content.Context
import android.content.Intent
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ExternalHardwareSnapshot(
    val keyboards: List<String> = emptyList(),
    val mice: List<String> = emptyList(),
    val isBridgeActive: Boolean = false
) {
    val hasKeyboard: Boolean get() = keyboards.isNotEmpty()
    val hasMouse: Boolean get() = mice.isNotEmpty()

    fun summaryLabel(): String {
        if (keyboards.isEmpty() && mice.isEmpty()) {
            return "Belum ada Keyboard/Mouse OTG atau Bluetooth terdeteksi"
        }
        val parts = mutableListOf<String>()
        if (keyboards.isNotEmpty()) {
            parts.add("Keyboard: ${keyboards.joinToString(", ") { it.take(18) }}")
        }
        if (mice.isNotEmpty()) {
            parts.add("Mouse: ${mice.joinToString(", ") { it.take(18) }}")
        }
        return parts.joinToString(" • ")
    }
}

object LvngInputDeviceMonitor {
    private val _snapshot = MutableStateFlow(ExternalHardwareSnapshot())
    val snapshot: StateFlow<ExternalHardwareSnapshot> = _snapshot.asStateFlow()

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var listenerRegistered = false

    private val mainHandler = Handler(Looper.getMainLooper())

    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            refresh()
        }

        override fun onInputDeviceRemoved(deviceId: Int) {
            refresh()
        }

        override fun onInputDeviceChanged(deviceId: Int) {
            refresh()
        }
    }

    fun init(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        if (!listenerRegistered) {
            listenerRegistered = true
            runCatching {
                val im = ctx.getSystemService(InputManager::class.java)
                im?.registerInputDeviceListener(deviceListener, mainHandler)
            }
        }
        refresh(ctx)
    }

    fun refresh(context: Context? = appContext): ExternalHardwareSnapshot {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) appContext = ctx

        val keyboards = LinkedHashSet<String>()
        val mice = LinkedHashSet<String>()

        runCatching {
            val ids = InputDevice.getDeviceIds()
            for (id in ids) {
                val dev = InputDevice.getDevice(id) ?: continue
                val (isMouse, isKb) = classifyDevice(dev)
                val cleanName = dev.name?.trim().orEmpty().ifBlank { "HID-$id" }
                if (isMouse) mice.add(cleanName)
                if (isKb) keyboards.add(cleanName)
            }
        }

        val bridgeOn = LvngKeyboardBridgeService.isServiceConnected ||
            (ctx != null && isAccessibilityEnabledInSettings(ctx))

        val snap = ExternalHardwareSnapshot(
            keyboards = keyboards.toList(),
            mice = mice.toList(),
            isBridgeActive = bridgeOn
        )
        _snapshot.value = snap
        return snap
    }

    fun classifyDevice(dev: InputDevice): Pair<Boolean, Boolean> {
        if (dev.isVirtual) return false to false
        val nameLower = dev.name.orEmpty().lowercase()
        if (nameLower.contains("lvng") ||
            nameLower.contains("uinput") ||
            nameLower.contains("touchscreen") ||
            nameLower.contains("fts") ||
            nameLower.contains("goodix") ||
            nameLower.contains("synaptics") ||
            nameLower.contains("fingerprint") ||
            nameLower.contains("gpio") ||
            nameLower.contains("qpnp") ||
            nameLower.contains("pmic") ||
            nameLower.contains("headset") ||
            nameLower.contains("haptics") ||
            nameLower.contains("sensor")
        ) {
            return false to false
        }

        val sources = dev.sources
        val isTouchscreen = (sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
        if (isTouchscreen && (sources and InputDevice.SOURCE_MOUSE) != InputDevice.SOURCE_MOUSE) {
            return false to false
        }

        val hasMouseSource =
            (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (sources and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
        val hasKeyboardSource =
            (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD ||
                (sources and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD &&
                dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC

        val isExternal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dev.isExternal
        } else {
            true
        }

        val isMouse = hasMouseSource && !isTouchscreen
        val hasAlphaOrCommonKeys = runCatching {
            dev.hasKeys(
                KeyEvent.KEYCODE_W,
                KeyEvent.KEYCODE_A,
                KeyEvent.KEYCODE_SPACE,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_F1
            ).any { it }
        }.getOrDefault(false)

        val isKeyboard = hasKeyboardSource && !isTouchscreen && (
            dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC ||
                (isExternal && hasAlphaOrCommonKeys) ||
                (isExternal && !isMouse)
            )

        return isMouse to isKeyboard
    }

    fun isAccessibilityEnabledInSettings(context: Context): Boolean {
        return runCatching {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ).orEmpty()
            val expectedShort = "${context.packageName}/${LvngKeyboardBridgeService::class.java.name}"
            val expectedCompact = "${context.packageName}/.input.LvngKeyboardBridgeService"
            enabled.contains(expectedShort, ignoreCase = true) ||
                enabled.contains(expectedCompact, ignoreCase = true)
        }.getOrDefault(false)
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }
}
