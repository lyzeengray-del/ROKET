package com.example.shizuku

import android.view.KeyEvent

/**
 * Canonical key & mouse codes shared between:
 * 1) Shizuku `/dev/input/event*` Linux evdev reader (`EV_KEY` / `EV_REL`),
 * 2) Compose Keymap Editor live key/mouse capture, and
 * 3) Persisted `KeyboardMouseConfig` JSON.
 *
 * Positive values match `android.view.KeyEvent.KEYCODE_*`;
 * Negative values (`-101..-107`) represent mouse buttons & wheel directions.
 */
object LvngKeyCodes {
    const val MOUSE_LEFT = -101
    const val MOUSE_RIGHT = -102
    const val MOUSE_MIDDLE = -103
    const val MOUSE_SIDE_BACK = -104
    const val MOUSE_SIDE_FORWARD = -105
    const val MOUSE_SCROLL_UP = -106
    const val MOUSE_SCROLL_DOWN = -107

    data class KeyOption(
        val code: Int,
        val shortLabel: String,
        val fullName: String
    )

    val mouseOptions: List<KeyOption> = listOf(
        KeyOption(MOUSE_LEFT, "LMB", "Klik Kiri Mouse"),
        KeyOption(MOUSE_RIGHT, "RMB", "Klik Kanan Mouse"),
        KeyOption(MOUSE_MIDDLE, "MMB", "Klik Tengah (Wheel)"),
        KeyOption(MOUSE_SIDE_BACK, "M4", "Tombol Samping M4"),
        KeyOption(MOUSE_SIDE_FORWARD, "M5", "Tombol Samping M5"),
        KeyOption(MOUSE_SCROLL_UP, "SCR+", "Scroll Atas"),
        KeyOption(MOUSE_SCROLL_DOWN, "SCR-", "Scroll Bawah")
    )

    val commonActionKeyOptions: List<KeyOption> = listOf(
        KeyOption(KeyEvent.KEYCODE_SPACE, "SPC", "Spasi"),
        KeyOption(KeyEvent.KEYCODE_SHIFT_LEFT, "SHF", "Shift Kiri"),
        KeyOption(KeyEvent.KEYCODE_CTRL_LEFT, "CTL", "Ctrl Kiri"),
        KeyOption(KeyEvent.KEYCODE_ALT_LEFT, "ALT", "Alt Kiri"),
        KeyOption(KeyEvent.KEYCODE_TAB, "TAB", "Tab"),
        KeyOption(KeyEvent.KEYCODE_GRAVE, "~", "Tilde (~)"),
        KeyOption(KeyEvent.KEYCODE_ESCAPE, "ESC", "Esc"),
        KeyOption(KeyEvent.KEYCODE_CAPS_LOCK, "CAP", "Caps Lock"),
        KeyOption(KeyEvent.KEYCODE_ENTER, "ENT", "Enter")
    )

    val letterKeyOptions: List<KeyOption> = listOf(
        KeyOption(KeyEvent.KEYCODE_Q, "Q", "Q"),
        KeyOption(KeyEvent.KEYCODE_W, "W", "W"),
        KeyOption(KeyEvent.KEYCODE_E, "E", "E"),
        KeyOption(KeyEvent.KEYCODE_R, "R", "R"),
        KeyOption(KeyEvent.KEYCODE_T, "T", "T"),
        KeyOption(KeyEvent.KEYCODE_Y, "Y", "Y"),
        KeyOption(KeyEvent.KEYCODE_U, "U", "U"),
        KeyOption(KeyEvent.KEYCODE_I, "I", "I"),
        KeyOption(KeyEvent.KEYCODE_O, "O", "O"),
        KeyOption(KeyEvent.KEYCODE_P, "P", "P"),
        KeyOption(KeyEvent.KEYCODE_A, "A", "A"),
        KeyOption(KeyEvent.KEYCODE_S, "S", "S"),
        KeyOption(KeyEvent.KEYCODE_D, "D", "D"),
        KeyOption(KeyEvent.KEYCODE_F, "F", "F"),
        KeyOption(KeyEvent.KEYCODE_G, "G", "G"),
        KeyOption(KeyEvent.KEYCODE_H, "H", "H"),
        KeyOption(KeyEvent.KEYCODE_J, "J", "J"),
        KeyOption(KeyEvent.KEYCODE_K, "K", "K"),
        KeyOption(KeyEvent.KEYCODE_L, "L", "L"),
        KeyOption(KeyEvent.KEYCODE_Z, "Z", "Z"),
        KeyOption(KeyEvent.KEYCODE_X, "X", "X"),
        KeyOption(KeyEvent.KEYCODE_C, "C", "C"),
        KeyOption(KeyEvent.KEYCODE_V, "V", "V"),
        KeyOption(KeyEvent.KEYCODE_B, "B", "B"),
        KeyOption(KeyEvent.KEYCODE_N, "N", "N"),
        KeyOption(KeyEvent.KEYCODE_M, "M", "M")
    )

    val numberAndFunctionOptions: List<KeyOption> = listOf(
        KeyOption(KeyEvent.KEYCODE_1, "1", "1"),
        KeyOption(KeyEvent.KEYCODE_2, "2", "2"),
        KeyOption(KeyEvent.KEYCODE_3, "3", "3"),
        KeyOption(KeyEvent.KEYCODE_4, "4", "4"),
        KeyOption(KeyEvent.KEYCODE_5, "5", "5"),
        KeyOption(KeyEvent.KEYCODE_6, "6", "6"),
        KeyOption(KeyEvent.KEYCODE_7, "7", "7"),
        KeyOption(KeyEvent.KEYCODE_8, "8", "8"),
        KeyOption(KeyEvent.KEYCODE_9, "9", "9"),
        KeyOption(KeyEvent.KEYCODE_0, "0", "0"),
        KeyOption(KeyEvent.KEYCODE_F1, "F1", "F1"),
        KeyOption(KeyEvent.KEYCODE_F2, "F2", "F2"),
        KeyOption(KeyEvent.KEYCODE_F3, "F3", "F3"),
        KeyOption(KeyEvent.KEYCODE_F4, "F4", "F4"),
        KeyOption(KeyEvent.KEYCODE_F5, "F5", "F5"),
        KeyOption(KeyEvent.KEYCODE_F6, "F6", "F6")
    )

    fun isMouseCode(code: Int): Boolean = code in MOUSE_SCROLL_DOWN..MOUSE_LEFT

    fun shortLabel(code: Int): String {
        return when (code) {
            KeyEvent.KEYCODE_UNKNOWN -> "?"
            MOUSE_LEFT -> "LMB"
            MOUSE_RIGHT -> "RMB"
            MOUSE_MIDDLE -> "MMB"
            MOUSE_SIDE_BACK -> "M4"
            MOUSE_SIDE_FORWARD -> "M5"
            MOUSE_SCROLL_UP -> "SCR+"
            MOUSE_SCROLL_DOWN -> "SCR-"
            KeyEvent.KEYCODE_SPACE -> "SPC"
            KeyEvent.KEYCODE_SHIFT_LEFT -> "SHF"
            KeyEvent.KEYCODE_SHIFT_RIGHT -> "RSHF"
            KeyEvent.KEYCODE_CTRL_LEFT -> "CTL"
            KeyEvent.KEYCODE_CTRL_RIGHT -> "RCTL"
            KeyEvent.KEYCODE_ALT_LEFT -> "ALT"
            KeyEvent.KEYCODE_ALT_RIGHT -> "RALT"
            KeyEvent.KEYCODE_TAB -> "TAB"
            KeyEvent.KEYCODE_GRAVE -> "~"
            KeyEvent.KEYCODE_ESCAPE -> "ESC"
            KeyEvent.KEYCODE_CAPS_LOCK -> "CAP"
            KeyEvent.KEYCODE_ENTER -> "ENT"
            KeyEvent.KEYCODE_DEL -> "BSP"
            KeyEvent.KEYCODE_DPAD_UP -> "UP"
            KeyEvent.KEYCODE_DPAD_DOWN -> "DN"
            KeyEvent.KEYCODE_DPAD_LEFT -> "LFT"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "RGT"
            KeyEvent.KEYCODE_F1 -> "F1"
            KeyEvent.KEYCODE_F2 -> "F2"
            KeyEvent.KEYCODE_F3 -> "F3"
            KeyEvent.KEYCODE_F4 -> "F4"
            KeyEvent.KEYCODE_F5 -> "F5"
            KeyEvent.KEYCODE_F6 -> "F6"
            KeyEvent.KEYCODE_F7 -> "F7"
            KeyEvent.KEYCODE_F8 -> "F8"
            KeyEvent.KEYCODE_F9 -> "F9"
            KeyEvent.KEYCODE_F10 -> "F10"
            KeyEvent.KEYCODE_F11 -> "F11"
            KeyEvent.KEYCODE_F12 -> "F12"
            else -> {
                val raw = KeyEvent.keyCodeToString(code)
                if (raw.startsWith("KEYCODE_")) {
                    raw.removePrefix("KEYCODE_").take(4)
                } else {
                    "K$code"
                }
            }
        }
    }

    /**
     * Maps Linux `input-event-codes.h` (`EV_KEY`) scan/key code to canonical `LvngKeyCodes` / Android `KeyEvent.KEYCODE_*`.
     * Returns `0` for unmapped hardware-only codes (touch contacts, power/internal buttons, etc.).
     */
    fun linuxEvKeyToCanonical(linuxCode: Int): Int {
        return when (linuxCode) {
            // Mouse buttons (BTN_MOUSE = 0x110 = 272)
            0x110 -> MOUSE_LEFT
            0x111 -> MOUSE_RIGHT
            0x112 -> MOUSE_MIDDLE
            0x113 -> MOUSE_SIDE_BACK
            0x114 -> MOUSE_SIDE_FORWARD

            // Row 1: Esc + Numbers + Backspace
            1 -> KeyEvent.KEYCODE_ESCAPE
            2 -> KeyEvent.KEYCODE_1
            3 -> KeyEvent.KEYCODE_2
            4 -> KeyEvent.KEYCODE_3
            5 -> KeyEvent.KEYCODE_4
            6 -> KeyEvent.KEYCODE_5
            7 -> KeyEvent.KEYCODE_6
            8 -> KeyEvent.KEYCODE_7
            9 -> KeyEvent.KEYCODE_8
            10 -> KeyEvent.KEYCODE_9
            11 -> KeyEvent.KEYCODE_0
            12 -> KeyEvent.KEYCODE_MINUS
            13 -> KeyEvent.KEYCODE_EQUALS
            14 -> KeyEvent.KEYCODE_DEL
            15 -> KeyEvent.KEYCODE_TAB

            // Row 2: Q - P
            16 -> KeyEvent.KEYCODE_Q
            17 -> KeyEvent.KEYCODE_W
            18 -> KeyEvent.KEYCODE_E
            19 -> KeyEvent.KEYCODE_R
            20 -> KeyEvent.KEYCODE_T
            21 -> KeyEvent.KEYCODE_Y
            22 -> KeyEvent.KEYCODE_U
            23 -> KeyEvent.KEYCODE_I
            24 -> KeyEvent.KEYCODE_O
            25 -> KeyEvent.KEYCODE_P
            26 -> KeyEvent.KEYCODE_LEFT_BRACKET
            27 -> KeyEvent.KEYCODE_RIGHT_BRACKET
            28 -> KeyEvent.KEYCODE_ENTER
            29 -> KeyEvent.KEYCODE_CTRL_LEFT

            // Row 3: A - L
            30 -> KeyEvent.KEYCODE_A
            31 -> KeyEvent.KEYCODE_S
            32 -> KeyEvent.KEYCODE_D
            33 -> KeyEvent.KEYCODE_F
            34 -> KeyEvent.KEYCODE_G
            35 -> KeyEvent.KEYCODE_H
            36 -> KeyEvent.KEYCODE_J
            37 -> KeyEvent.KEYCODE_K
            38 -> KeyEvent.KEYCODE_L
            39 -> KeyEvent.KEYCODE_SEMICOLON
            40 -> KeyEvent.KEYCODE_APOSTROPHE
            41 -> KeyEvent.KEYCODE_GRAVE
            42 -> KeyEvent.KEYCODE_SHIFT_LEFT
            43 -> KeyEvent.KEYCODE_BACKSLASH

            // Row 4: Z - M
            44 -> KeyEvent.KEYCODE_Z
            45 -> KeyEvent.KEYCODE_X
            46 -> KeyEvent.KEYCODE_C
            47 -> KeyEvent.KEYCODE_V
            48 -> KeyEvent.KEYCODE_B
            49 -> KeyEvent.KEYCODE_N
            50 -> KeyEvent.KEYCODE_M
            51 -> KeyEvent.KEYCODE_COMMA
            52 -> KeyEvent.KEYCODE_PERIOD
            53 -> KeyEvent.KEYCODE_SLASH
            54 -> KeyEvent.KEYCODE_SHIFT_RIGHT
            55 -> KeyEvent.KEYCODE_NUMPAD_MULTIPLY
            56 -> KeyEvent.KEYCODE_ALT_LEFT
            57 -> KeyEvent.KEYCODE_SPACE
            58 -> KeyEvent.KEYCODE_CAPS_LOCK

            // Function keys F1 - F10
            59 -> KeyEvent.KEYCODE_F1
            60 -> KeyEvent.KEYCODE_F2
            61 -> KeyEvent.KEYCODE_F3
            62 -> KeyEvent.KEYCODE_F4
            63 -> KeyEvent.KEYCODE_F5
            64 -> KeyEvent.KEYCODE_F6
            65 -> KeyEvent.KEYCODE_F7
            66 -> KeyEvent.KEYCODE_F8
            67 -> KeyEvent.KEYCODE_F9
            68 -> KeyEvent.KEYCODE_F10
            87 -> KeyEvent.KEYCODE_F11
            88 -> KeyEvent.KEYCODE_F12

            // Numpad
            71 -> KeyEvent.KEYCODE_NUMPAD_7
            72 -> KeyEvent.KEYCODE_NUMPAD_8
            73 -> KeyEvent.KEYCODE_NUMPAD_9
            74 -> KeyEvent.KEYCODE_NUMPAD_SUBTRACT
            75 -> KeyEvent.KEYCODE_NUMPAD_4
            76 -> KeyEvent.KEYCODE_NUMPAD_5
            77 -> KeyEvent.KEYCODE_NUMPAD_6
            78 -> KeyEvent.KEYCODE_NUMPAD_ADD
            79 -> KeyEvent.KEYCODE_NUMPAD_1
            80 -> KeyEvent.KEYCODE_NUMPAD_2
            81 -> KeyEvent.KEYCODE_NUMPAD_3
            82 -> KeyEvent.KEYCODE_NUMPAD_0
            83 -> KeyEvent.KEYCODE_NUMPAD_DOT
            96 -> KeyEvent.KEYCODE_NUMPAD_ENTER

            // Modifiers & Arrows
            97 -> KeyEvent.KEYCODE_CTRL_RIGHT
            100 -> KeyEvent.KEYCODE_ALT_RIGHT
            102 -> KeyEvent.KEYCODE_MOVE_HOME
            103 -> KeyEvent.KEYCODE_DPAD_UP
            104 -> KeyEvent.KEYCODE_PAGE_UP
            105 -> KeyEvent.KEYCODE_DPAD_LEFT
            106 -> KeyEvent.KEYCODE_DPAD_RIGHT
            107 -> KeyEvent.KEYCODE_MOVE_END
            108 -> KeyEvent.KEYCODE_DPAD_DOWN
            109 -> KeyEvent.KEYCODE_PAGE_DOWN
            110 -> KeyEvent.KEYCODE_INSERT
            111 -> KeyEvent.KEYCODE_FORWARD_DEL
            125 -> KeyEvent.KEYCODE_META_LEFT
            126 -> KeyEvent.KEYCODE_META_RIGHT
            else -> 0
        }
    }
}
