package com.example.shizuku

import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.os.Process as AndroidProcess
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.InputChannel
import android.view.InputDevice
import android.view.InputEvent
import android.view.InputEventReceiver
import android.view.InputMonitor
import android.view.MotionEvent
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.LockSupport

/**
 * Isolated helper for `InputMonitor` / `InputEventReceiver` so ART only loads/verifies
 * hidden `android.view.Input*` types AFTER `VMRuntime.setHiddenApiExemptions` has run.
 */
private class LvngInputMonitorHost private constructor(
    private val monitor: InputMonitor,
    private val thread: HandlerThread,
    private val receiver: InputEventReceiver,
    val sourceDescription: String
) {
    fun dispose() {
        val looper = runCatching { thread.looper }.getOrNull()
        if (looper != null && thread.isAlive && Looper.myLooper() != looper) {
            val latch = CountDownLatch(1)
            val posted = runCatching {
                Handler(looper).post {
                    runCatching { receiver.dispose() }
                    runCatching { monitor.dispose() }
                    runCatching { thread.quitSafely() }
                    latch.countDown()
                }
            }.getOrDefault(false)
            if (posted) {
                runCatching { latch.await(300L, TimeUnit.MILLISECONDS) }
                return
            }
        }
        runCatching { receiver.dispose() }
        runCatching { monitor.dispose() }
        runCatching { thread.quitSafely() }
    }

    companion object {
        private const val MONITOR_NAME = "lvng-macro"

        private fun unwrap(t: Throwable): Throwable {
            return if (t is InvocationTargetException) (t.targetException ?: t) else t
        }

        fun open(
            iInputManagerObj: Any?,
            onMotionEvent: (MotionEvent) -> Unit
        ): Pair<LvngInputMonitorHost?, String> {
            val attempts = mutableListOf<String>()
            var monitor: InputMonitor? = null
            var sourceName = ""

            // 1) Android 14–16 (API 34–36): InputManagerGlobal.getInstance().monitorGestureInput(name, displayId)
            if (monitor == null) {
                try {
                    val imgClass = Class.forName("android.hardware.input.InputManagerGlobal")
                    val inst = imgClass.getMethod("getInstance").invoke(null)
                    val m = imgClass.getMethod(
                        "monitorGestureInput",
                        String::class.java,
                        Int::class.javaPrimitiveType
                    ).apply { isAccessible = true }
                    val res = m.invoke(inst, MONITOR_NAME, Display.DEFAULT_DISPLAY) as? InputMonitor
                    if (res != null) {
                        monitor = res
                        sourceName = "InputManagerGlobal"
                    }
                } catch (t: Throwable) {
                    val u = unwrap(t)
                    attempts.add("InputManagerGlobal=${u.javaClass.simpleName}:${u.message}")
                }
            }

            // 2) Android 12–13 (API 31–33): InputManager.getInstance().monitorGestureInput(name, displayId)
            if (monitor == null) {
                try {
                    val imClass = Class.forName("android.hardware.input.InputManager")
                    val inst = imClass.getMethod("getInstance").invoke(null)
                    val m = imClass.getMethod(
                        "monitorGestureInput",
                        String::class.java,
                        Int::class.javaPrimitiveType
                    ).apply { isAccessible = true }
                    val res = m.invoke(inst, MONITOR_NAME, Display.DEFAULT_DISPLAY) as? InputMonitor
                    if (res != null) {
                        monitor = res
                        sourceName = "InputManager"
                    }
                } catch (t: Throwable) {
                    val u = unwrap(t)
                    attempts.add("InputManager=${u.javaClass.simpleName}:${u.message}")
                }
            }

            // 3) Direct Binder: IInputManager.monitorGestureInput (3-arg with token or 2-arg)
            if (monitor == null && iInputManagerObj != null) {
                val resPair = tryBinderMonitorGestureInput(iInputManagerObj, "IInputManager")
                if (resPair.first != null) {
                    monitor = resPair.first
                    sourceName = resPair.second
                } else {
                    attempts.add(resPair.second)
                }
            }

            // 4) Android 11–13: IWindowManager.monitorGestureInput (2-arg on API 30, 3-arg on API 31–33)
            if (monitor == null) {
                try {
                    val smClass = Class.forName("android.os.ServiceManager")
                    val getService = smClass.getMethod("getService", String::class.java)
                    val wmBinder = getService.invoke(null, "window") as? IBinder
                    if (wmBinder != null) {
                        val wmStub = Class.forName("android.view.IWindowManager\$Stub")
                        val wm = wmStub.getMethod("asInterface", IBinder::class.java).invoke(null, wmBinder)
                        if (wm != null) {
                            val resPair = tryBinderMonitorGestureInput(wm, "IWindowManager")
                            if (resPair.first != null) {
                                monitor = resPair.first
                                sourceName = resPair.second
                            } else {
                                attempts.add(resPair.second)
                            }
                        } else {
                            attempts.add("IWindowManager=null")
                        }
                    } else {
                        attempts.add("windowBinder=null")
                    }
                } catch (t: Throwable) {
                    val u = unwrap(t)
                    attempts.add("IWindowManager=${u.javaClass.simpleName}:${u.message}")
                }
            }

            val resolvedMonitor = monitor
                ?: return null to "monitorGestureInput gagal [${attempts.joinToString("; ")}]"

            val channel: InputChannel = try {
                resolvedMonitor.inputChannel
            } catch (t: Throwable) {
                runCatching { resolvedMonitor.dispose() }
                val u = unwrap(t)
                return null to "InputMonitor.getInputChannel gagal: ${u.javaClass.simpleName}: ${u.message}"
            }

            val thread = HandlerThread("LvngInputMonitor", AndroidProcess.THREAD_PRIORITY_URGENT_DISPLAY)
            thread.start()
            val looper: Looper = thread.looper

            val createdReceiver = arrayOfNulls<InputEventReceiver>(1)
            val initError = arrayOfNulls<Throwable>(1)
            val initLatch = CountDownLatch(1)

            Handler(looper).post {
                try {
                    createdReceiver[0] = object : InputEventReceiver(channel, looper) {
                        override fun onInputEvent(event: InputEvent) {
                            try {
                                if (event is MotionEvent) {
                                    onMotionEvent(event)
                                }
                            } finally {
                                finishInputEvent(event, false)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    initError[0] = t
                } finally {
                    initLatch.countDown()
                }
            }

            runCatching { initLatch.await(1_000L, TimeUnit.MILLISECONDS) }
            val receiver = createdReceiver[0]
            if (receiver == null) {
                val err = initError[0]?.let { unwrap(it) }
                runCatching { resolvedMonitor.dispose() }
                runCatching { thread.quitSafely() }
                val reason = if (err != null) {
                    "InputEventReceiver gagal: ${err.javaClass.simpleName}: ${err.message}"
                } else {
                    "InputEventReceiver timeout"
                }
                return null to reason
            }

            return LvngInputMonitorHost(resolvedMonitor, thread, receiver, sourceName) to sourceName
        }

        private fun tryBinderMonitorGestureInput(service: Any, tag: String): Pair<InputMonitor?, String> {
            val methods = service.javaClass.methods.filter { it.name == "monitorGestureInput" }
            if (methods.isEmpty()) return null to "$tag=noMethod"
            val errors = mutableListOf<String>()
            for (m in methods.sortedByDescending { it.parameterTypes.size }) {
                try {
                    m.isAccessible = true
                    val params = m.parameterTypes
                    val res = when {
                        params.size == 3 &&
                            IBinder::class.java.isAssignableFrom(params[0]) &&
                            params[1] == String::class.java &&
                            params[2] == Int::class.javaPrimitiveType -> {
                            m.invoke(service, Binder(), MONITOR_NAME, Display.DEFAULT_DISPLAY)
                        }
                        params.size == 2 &&
                            params[0] == String::class.java &&
                            params[1] == Int::class.javaPrimitiveType -> {
                            m.invoke(service, MONITOR_NAME, Display.DEFAULT_DISPLAY)
                        }
                        else -> continue
                    }
                    if (res is InputMonitor) {
                        return res to "$tag(${params.size}arg)"
                    }
                } catch (t: Throwable) {
                    val u = unwrap(t)
                    errors.add("${m.parameterTypes.size}arg:${u.javaClass.simpleName}:${u.message}")
                }
            }
            return null to "$tag=[${errors.joinToString(",")}]"
        }
    }
}

/**
 * Privileged UserService executed inside Shizuku's process (uid 2000 shell).
 *
 * Cross-Android (Android 11–16 / API 30–36) Multi-Touch Macro Backend:
 * - Unlocks hidden APIs immediately upon service construction.
 * - Uses `IInputManager.injectInputEvent` (with `InputManagerGlobal` / `InputManager` fallback)
 *   paired with `LvngInputMonitorHost` (`InputMonitor` + `InputEventReceiver`) to merge virtual
 *   macro touches (`MACRO_POINTER_ID = 29`) seamlessly onto active physical touches using
 *   `ACTION_POINTER_DOWN` / `ACTION_POINTER_UP` with matching `deviceId`, `source`, `displayId`,
 *   and `downTime`.
 */
@Keep
class LvngShizukuInputService : Binder() {

    private fun toSnapshot(me: MotionEvent, index: Int, id: Int): PointerStreamCoordinator.PointerSnapshot {
        return PointerStreamCoordinator.PointerSnapshot(
            id = id,
            x = me.getX(index),
            y = me.getY(index),
            pressure = me.getPressure(index).coerceIn(0.05f, 1.0f),
            size = me.getSize(index).coerceAtLeast(0.04f),
            touchMajor = me.getTouchMajor(index).let { if (it > 0f) it else 12f },
            touchMinor = me.getTouchMinor(index).let { if (it > 0f) it else 12f },
            toolType = me.getToolType(index).let {
                if (it == MotionEvent.TOOL_TYPE_UNKNOWN) MotionEvent.TOOL_TYPE_FINGER else it
            }
        )
    }

    private object HiddenApiHelper {
        private val initDone = AtomicBoolean(false)

        @Volatile
        var unlockError: String? = null
            private set

        fun unlock(): String? {
            if (!initDone.compareAndSet(false, true)) return unlockError
            val err = runUnlock()
            unlockError = err
            if (err != null) {
                Log.w(DIAG_TAG, "unlockHiddenApis warning: $err")
            } else {
                Log.i(DIAG_TAG, "unlockHiddenApis OK (API ${Build.VERSION.SDK_INT})")
            }
            return err
        }

        private fun runUnlock(): String? {
            return try {
                val classArrayType = emptyArray<Class<*>>()::class.java
                val stringArrayType = emptyArray<String>()::class.java
                val forName = Class::class.java.getDeclaredMethod("forName", String::class.java)
                val getDeclaredMethod = Class::class.java.getDeclaredMethod(
                    "getDeclaredMethod",
                    String::class.java,
                    classArrayType
                )
                val vmRuntimeClass = forName.invoke(null, "dalvik.system.VMRuntime") as Class<*>
                val getRuntime = getDeclaredMethod.invoke(
                    vmRuntimeClass,
                    "getRuntime",
                    emptyArray<Class<*>>()
                ) as Method
                val setExemptions = getDeclaredMethod.invoke(
                    vmRuntimeClass,
                    "setHiddenApiExemptions",
                    arrayOf<Class<*>>(stringArrayType)
                ) as Method
                getRuntime.isAccessible = true
                setExemptions.isAccessible = true
                val runtime = getRuntime.invoke(null)
                setExemptions.invoke(runtime, arrayOf("L"))
                null
            } catch (t1: Throwable) {
                try {
                    val stringArrayType = emptyArray<String>()::class.java
                    val vmRuntimeClass = Class.forName("dalvik.system.VMRuntime")
                    val getRuntime = vmRuntimeClass.getDeclaredMethod("getRuntime").apply { isAccessible = true }
                    val setExemptions = vmRuntimeClass.getDeclaredMethod(
                        "setHiddenApiExemptions",
                        stringArrayType
                    ).apply { isAccessible = true }
                    setExemptions.invoke(getRuntime.invoke(null), arrayOf("L"))
                    null
                } catch (t2: Throwable) {
                    val u1 = unwrap(t1)
                    val u2 = unwrap(t2)
                    "meta=${u1.javaClass.simpleName}:${u1.message}; direct=${u2.javaClass.simpleName}:${u2.message}"
                }
            }
        }
    }

    private inner class FrameworkTouchInjector : VirtualPointerHost {
        private val lifecycleLock = Any()
        private val injectLock = Any()
        private val streamLock = Any()

        private val ready = AtomicBoolean(false)

        @Volatile
        var status: String = COMPOSITOR_STOPPED
            private set

        @Volatile
        var detail: String = "InputInjector belum dimulai"
            private set

        @Volatile
        private var inputInjectorObj: Any? = null

        @Volatile
        private var iInputManagerObj: Any? = null

        @Volatile
        private var injectInputEventMethod: Method? = null

        @Volatile
        private var setDisplayIdMethod: Method? = null

        @Volatile
        private var getDisplayIdMethod: Method? = null

        @Volatile
        private var monitorHost: LvngInputMonitorHost? = null

        @Volatile
        private var monitorWarning: String? = null

        @Volatile
        private var resolvedTouchDeviceId: Int = 0

        @Volatile
        private var lastInjectFailureDetail: String? = null

        @Volatile
        private var hasVerifiedTouchInjection: Boolean = false

        // Single coordinated stream state guarded by streamLock:
        // physical 0..14 | macro 15 | wasd 16 | mouseAim 17 | aimPan 18 | sentuh 19..31
        private val streamCoordinator = PointerStreamCoordinator()

        private fun updateState(newStatus: String, newDetail: String, isError: Boolean = false) {
            status = newStatus
            detail = newDetail
            if (isError) {
                Log.e(DIAG_TAG, "Injector status=$newStatus | $newDetail")
            } else {
                Log.i(DIAG_TAG, "Injector status=$newStatus | $newDetail")
            }
        }

        fun isReady(): Boolean = ready.get() && status == COMPOSITOR_GRABBED && inputInjectorObj != null

        fun start(): Boolean {
            synchronized(lifecycleLock) {
                if (isReady()) return true

                updateState(COMPOSITOR_STARTING, "Menyiapkan Android ${Build.VERSION.RELEASE} InputInjector...")
                HiddenApiHelper.unlock()

                if (!ensureBinderMethods()) {
                    ready.set(false)
                    return false
                }

                if (resolvedTouchDeviceId <= 0) {
                    resolvedTouchDeviceId = discoverPhysicalTouchDeviceId()
                }

                openMonitorLocked()

                lastInjectFailureDetail = null
                ready.set(true)
                val monInfo = monitorHost?.sourceDescription ?: "no-monitor (${monitorWarning ?: "unknown"})"
                updateState(
                    COMPOSITOR_GRABBED,
                    "Aktif (API ${Build.VERSION.SDK_INT}, $monInfo, devId=$resolvedTouchDeviceId)"
                )
                return true
            }
        }

        // Membuka InputMonitor bila belum ada. Wajib dipanggil di dalam lifecycleLock.
        private fun openMonitorLocked() {
            if (monitorHost != null) return
            val (host, monitorDesc) = runCatching {
                LvngInputMonitorHost.open(iInputManagerObj) { me ->
                    onMonitorMotionEvent(me)
                }
            }.getOrElse { t ->
                val u = unwrap(t)
                null to "LvngInputMonitorHost exception: ${u.javaClass.simpleName}: ${u.message}"
            }

            if (host != null) {
                monitorHost = host
                monitorWarning = null
            } else {
                monitorWarning = monitorDesc
                Log.w(DIAG_TAG, "InputMonitor tidak tersedia, lanjut single-pointer fallback: $monitorDesc")
            }
        }

        /** Coba buka ulang monitor (mis. gagal saat warmup) sebelum loop Macro berjalan. */
        fun ensureMonitorOpen() {
            if (monitorHost != null) return
            synchronized(lifecycleLock) { openMonitorLocked() }
        }

        // True selama loop Macro (Trigger ditahan) berjalan. Saat itu pasti ada minimal satu
        // sentuhan fisik (jari di Trigger), jadi ACTION_DOWN tunggal tidak boleh disuntik.
        @Volatile
        private var macroLoopActive = false
        private var consecutiveSoloSkips = 0
        private var collisionCount = 0L
        private var lastCollisionLogMs = 0L

        fun setMacroLoopActive(active: Boolean) {
            macroLoopActive = active
            if (!active) consecutiveSoloSkips = 0
        }

        override fun ensureInjectorStarted(): Boolean = isReady() || start()

        fun stop() {
            synchronized(lifecycleLock) {
                releaseMacroIfActive()
                releaseAllKeymapPointers()
                ready.set(false)
                hasVerifiedTouchInjection = false
                val prevHost = monitorHost
                monitorHost = null
                prevHost?.dispose()
                synchronized(streamLock) {
                    streamCoordinator.clearAll()
                }
                if (status != COMPOSITOR_FAILED) {
                    updateState(COMPOSITOR_STOPPED, "InputInjector dihentikan")
                }
            }
        }

        fun markFailed(reason: String) {
            ready.set(false)
            updateState(COMPOSITOR_FAILED, reason, isError = true)
        }

        private fun ensureBinderMethods(): Boolean {
            if (inputInjectorObj != null && injectInputEventMethod != null) return true
            val errors = mutableListOf<String>()

            // Resolve displayId helpers
            setDisplayIdMethod = runCatching {
                MotionEvent::class.java.methods.firstOrNull {
                    it.name == "setDisplayId" && it.parameterTypes.size == 1 &&
                        it.parameterTypes[0] == Int::class.javaPrimitiveType
                }?.apply { isAccessible = true }
            }.getOrNull()

            getDisplayIdMethod = runCatching {
                InputEvent::class.java.methods.firstOrNull {
                    it.name == "getDisplayId" && it.parameterTypes.isEmpty()
                }?.apply { isAccessible = true }
            }.getOrNull()

            // 1) Try direct IInputManager Binder via ServiceManager
            try {
                val smClass = Class.forName("android.os.ServiceManager")
                val getService = smClass.getMethod("getService", String::class.java)
                val inputBinder = getService.invoke(null, "input") as? IBinder
                if (inputBinder != null) {
                    val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
                    val im = stubClass.getMethod("asInterface", IBinder::class.java).invoke(null, inputBinder)
                    if (im != null) {
                        iInputManagerObj = im
                        val m = runCatching {
                            im.javaClass.getMethod(
                                "injectInputEvent",
                                InputEvent::class.java,
                                Int::class.javaPrimitiveType
                            ).apply { isAccessible = true }
                        }.getOrNull()
                        if (m != null) {
                            inputInjectorObj = im
                            injectInputEventMethod = m
                            return true
                        }
                        errors.add("IInputManager.injectInputEvent tidak ditemukan")
                    } else {
                        errors.add("IInputManager.Stub.asInterface=null")
                    }
                } else {
                    errors.add("ServiceManager.getService(input)=null")
                }
            } catch (t: Throwable) {
                val u = unwrap(t)
                errors.add("IInputManager=${u.javaClass.simpleName}:${u.message}")
            }

            // 2) Try InputManagerGlobal.getInstance() (Android 14–16)
            try {
                val imgClass = Class.forName("android.hardware.input.InputManagerGlobal")
                val inst = imgClass.getMethod("getInstance").invoke(null)
                val m = imgClass.methods.firstOrNull {
                    it.name == "injectInputEvent" &&
                        it.parameterTypes.size == 2 &&
                        InputEvent::class.java.isAssignableFrom(it.parameterTypes[0]) &&
                        it.parameterTypes[1] == Int::class.javaPrimitiveType
                }?.apply { isAccessible = true }
                if (inst != null && m != null) {
                    inputInjectorObj = inst
                    injectInputEventMethod = m
                    return true
                }
            } catch (t: Throwable) {
                val u = unwrap(t)
                errors.add("InputManagerGlobal=${u.javaClass.simpleName}:${u.message}")
            }

            // 3) Try InputManager.getInstance() (Android 11–13)
            try {
                val imClass = Class.forName("android.hardware.input.InputManager")
                val inst = imClass.getMethod("getInstance").invoke(null)
                val m = imClass.methods.firstOrNull {
                    it.name == "injectInputEvent" &&
                        it.parameterTypes.size == 2 &&
                        InputEvent::class.java.isAssignableFrom(it.parameterTypes[0]) &&
                        it.parameterTypes[1] == Int::class.javaPrimitiveType
                }?.apply { isAccessible = true }
                if (inst != null && m != null) {
                    inputInjectorObj = inst
                    injectInputEventMethod = m
                    return true
                }
            } catch (t: Throwable) {
                val u = unwrap(t)
                errors.add("InputManager=${u.javaClass.simpleName}:${u.message}")
            }

            updateState(
                COMPOSITOR_FAILED,
                "IInputManager tidak tersedia [${errors.joinToString("; ")}]",
                isError = true
            )
            return false
        }

        private fun onMonitorMotionEvent(me: MotionEvent) {
            if ((me.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (me.source and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
            ) {
                keymapEngine.onFrameworkMouseEvent(me)
                return
            }
            if ((me.source and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) return

            val pointerCount = me.pointerCount
            if (pointerCount <= 0) return

            val actionMasked = me.actionMasked
            if (actionMasked != MotionEvent.ACTION_DOWN &&
                actionMasked != MotionEvent.ACTION_POINTER_DOWN &&
                actionMasked != MotionEvent.ACTION_MOVE &&
                actionMasked != MotionEvent.ACTION_POINTER_UP &&
                actionMasked != MotionEvent.ACTION_UP &&
                actionMasked != MotionEvent.ACTION_CANCEL
            ) {
                return
            }

            // Hardware touchscreens never emit virtual IDs (15..31). Dropping ANY event that
            // contains a virtual pointer ID prevents our own injected ACTION_MOVE/POINTER_*
            // events from echoing back and overwriting live Finger 1 swipes or lifted touches.
            val snapshots = ArrayList<PointerStreamCoordinator.PointerSnapshot>(pointerCount)
            for (i in 0 until pointerCount) {
                val pid = me.getPointerId(i)
                if (PointerStreamCoordinator.isVirtualPointerId(pid)) {
                    return
                }
                snapshots.add(toSnapshot(me, i, pid))
            }
            if (snapshots.isEmpty()) return

            val actionIdx = me.actionIndex

            val observedDisp = runCatching {
                (getDisplayIdMethod?.invoke(me) as? Int) ?: Display.DEFAULT_DISPLAY
            }.getOrDefault(Display.DEFAULT_DISPLAY)

            if (me.deviceId > 0) {
                resolvedTouchDeviceId = me.deviceId
            }

            synchronized(streamLock) {
                // Diagnostik: event fisik non-MOVE (jari baru turun/naik) yang tiba saat pointer virtual
                // sedang aktif adalah titik tabrakan dua stream (lihat logcat tag LvngTouchInjector).
                if (actionMasked != MotionEvent.ACTION_MOVE && streamCoordinator.activeVirtualCount() > 0) {
                    collisionCount++
                    val nowLog = SystemClock.uptimeMillis()
                    if (nowLog - lastCollisionLogMs >= 2_000L) {
                        lastCollisionLogMs = nowLog
                        Log.w(
                            DIAG_TAG,
                            "Tabrakan stream: event fisik action=$actionMasked tiba saat pointer virtual aktif " +
                                "(virtual=${streamCoordinator.activeVirtualIds()}, fisik=${streamCoordinator.activePhysicalIds()}, total=$collisionCount)"
                        )
                    }
                }
                streamCoordinator.onPhysicalEvent(
                    actionMasked = actionMasked,
                    actionIndex = actionIdx,
                    downTime = me.downTime,
                    deviceId = me.deviceId,
                    source = me.source,
                    displayId = observedDisp,
                    eventPointers = snapshots
                )
            }
        }

        private fun discoverPhysicalTouchDeviceId(): Int {
            return runCatching {
                val ids = InputDevice.getDeviceIds()
                var bestId = 0
                var bestArea = -1f
                for (id in ids) {
                    val dev = InputDevice.getDevice(id) ?: continue
                    if (!dev.isEnabled || dev.isVirtual) continue
                    val sources = dev.sources
                    if ((sources and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) continue
                    if (dev.name.equals(LEGACY_VIRTUAL_NAME, ignoreCase = true)) continue
                    val rx = dev.getMotionRange(MotionEvent.AXIS_X)
                    val ry = dev.getMotionRange(MotionEvent.AXIS_Y)
                    val area = if (rx != null && ry != null) rx.max * ry.max else 0f
                    if (bestId == 0 || area > bestArea) {
                        bestId = id
                        bestArea = area
                    }
                }
                bestId
            }.getOrDefault(0)
        }

        fun tapOnce(
            xPx: Float,
            yPx: Float,
            holdMs: Long,
            genCheck: Long?
        ): Boolean {
            if (!isReady() && !start()) return false

            var downSent = false
            try {
                downSent = upsertVirtualPointerInternal(MACRO_POINTER_ID, xPx, yPx, markFailedOnZeroContacts = true)
                if (!downSent) {
                    return false
                }
                if (holdMs > 0L) {
                    sleepPreciseMs(holdMs, genCheck)
                }
            } finally {
                if (downSent) {
                    removeVirtualPointer(MACRO_POINTER_ID)
                }
            }
            return true
        }

        fun releaseMacroIfActive() {
            removeVirtualPointer(MACRO_POINTER_ID)
        }

        private fun upsertVirtualPointerInternal(
            pointerId: Int,
            xPx: Float,
            yPx: Float,
            markFailedOnZeroContacts: Boolean
        ): Boolean {
            if (!isReady() && !start()) return false
            synchronized(injectLock) {
                val firstPlan = synchronized(streamLock) {
                    streamCoordinator.planUpsert(
                        pointerId = pointerId,
                        xPx = xPx,
                        yPx = yPx,
                        nowMs = SystemClock.uptimeMillis(),
                        fallbackTouchDeviceId = resolvedTouchDeviceId
                    )
                }

                if (firstPlan is PointerStreamCoordinator.UpsertPlan.MoveExisting) {
                    return injectPlannedEvent(firstPlan.event, INJECT_MODE_ASYNC)
                }

                var joinPlan = firstPlan as PointerStreamCoordinator.UpsertPlan.JoinOrDown
                if (!joinPlan.isFreshDown) {
                    // Non-preemption rule: while ANY physical or virtual contact is active,
                    // NEVER fall back to solo ACTION_DOWN or clear active pointers.
                    // Once touch injection permission is verified, use ASYNC so rapid macro taps
                    // never stall InputDispatcher or freeze concurrent Finger 1 HUD/camera drags.
                    val joinMode = if (hasVerifiedTouchInjection) {
                        INJECT_MODE_ASYNC
                    } else {
                        INJECT_MODE_WAIT_FOR_RESULT
                    }
                    for (attempt in 0 until 2) {
                        if (injectPlannedEvent(joinPlan.event, joinMode)) {
                            hasVerifiedTouchInjection = true
                            synchronized(streamLock) { streamCoordinator.commitUpsert(joinPlan) }
                            if (pointerId == MACRO_POINTER_ID) consecutiveSoloSkips = 0
                            return true
                        }
                        if (!isReady() || attempt > 0) break
                        Thread.yield()
                        val replanned = synchronized(streamLock) {
                            streamCoordinator.planUpsert(
                                pointerId = pointerId,
                                xPx = xPx,
                                yPx = yPx,
                                nowMs = SystemClock.uptimeMillis(),
                                fallbackTouchDeviceId = resolvedTouchDeviceId
                            )
                        }
                        when (replanned) {
                            is PointerStreamCoordinator.UpsertPlan.MoveExisting ->
                                return injectPlannedEvent(replanned.event, INJECT_MODE_ASYNC)
                            is PointerStreamCoordinator.UpsertPlan.JoinOrDown -> {
                                if (replanned.isFreshDown) {
                                    joinPlan = replanned
                                    break
                                }
                                joinPlan = replanned
                            }
                        }
                    }
                    if (!joinPlan.isFreshDown) {
                        return false
                    }
                }

                // Reached ONLY when 0 active contacts exist across both physical and virtual streams.
                // Selama Trigger ditahan, jari Trigger adalah kontak fisik yang pasti ada. Jika snapshot
                // monitor masih kosong (monitor belum memproses DOWN), menyuntik ACTION_DOWN tunggal akan
                // menimpa stream fisik di dispatcher dan memutus drag/joystick di HUD game. Lewati siklus
                // ini (maks MAX_SOLO_SKIPS berturut-turut) agar snapshot sempat tersinkron.
                if (pointerId == MACRO_POINTER_ID && macroLoopActive && monitorHost != null &&
                    consecutiveSoloSkips < MAX_SOLO_SKIPS
                ) {
                    consecutiveSoloSkips++
                    Log.w(
                        DIAG_TAG,
                        "Macro tap dilewati: snapshot fisik kosong saat Trigger ditahan " +
                            "(skip=$consecutiveSoloSkips/$MAX_SOLO_SKIPS)"
                    )
                    return false
                }
                val preferredDevId = joinPlan.event.deviceId
                val candidateDevIds = if (preferredDevId != 0) intArrayOf(preferredDevId, 0) else intArrayOf(0)
                for (candDevId in candidateDevIds) {
                    if (!isReady()) break
                    val soloPlan = synchronized(streamLock) {
                        if (streamCoordinator.hasAnyActiveContact()) {
                            return false
                        }
                        streamCoordinator.planUpsert(
                            pointerId = pointerId,
                            xPx = xPx,
                            yPx = yPx,
                            nowMs = SystemClock.uptimeMillis(),
                            fallbackTouchDeviceId = resolvedTouchDeviceId,
                            forcedSoloDeviceId = candDevId
                        )
                    } as? PointerStreamCoordinator.UpsertPlan.JoinOrDown ?: return false

                    if (injectPlannedEvent(soloPlan.event, INJECT_MODE_WAIT_FOR_RESULT)) {
                        hasVerifiedTouchInjection = true
                        synchronized(streamLock) {
                            if (candDevId == 0 && preferredDevId != 0) {
                                streamCoordinator.preferZeroDevIdForSolo = true
                            }
                            streamCoordinator.commitUpsert(soloPlan)
                        }
                        return true
                    }
                }

                if (markFailedOnZeroContacts && status != COMPOSITOR_FAILED) {
                    val reason = lastInjectFailureDetail
                        ?: "IInputManager.injectInputEvent ditolak sistem (aktifkan Debugging USB - Setelan keamanan di Opsi Developer)"
                    markFailed(reason)
                }
                return false
            }
        }

        override fun upsertVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean =
            upsertVirtualPointerInternal(pointerId, xPx, yPx, markFailedOnZeroContacts = false)

        override fun moveVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean {
            if (!isReady()) return false
            synchronized(injectLock) {
                val planned = synchronized(streamLock) {
                    streamCoordinator.planMove(
                        pointerId = pointerId,
                        xPx = xPx,
                        yPx = yPx,
                        nowMs = SystemClock.uptimeMillis(),
                        fallbackTouchDeviceId = resolvedTouchDeviceId
                    )
                } ?: return false
                return injectPlannedEvent(planned, INJECT_MODE_ASYNC)
            }
        }

        override fun removeVirtualPointer(pointerId: Int): Boolean {
            synchronized(injectLock) {
                for (attempt in 0 until 2) {
                    val planned = synchronized(streamLock) {
                        streamCoordinator.planRemove(
                            pointerId = pointerId,
                            nowMs = SystemClock.uptimeMillis(),
                            fallbackTouchDeviceId = resolvedTouchDeviceId
                        )
                    } ?: return false
                    if (injectPlannedEvent(planned, INJECT_MODE_ASYNC)) {
                        synchronized(streamLock) {
                            streamCoordinator.commitRemove(pointerId)
                        }
                        return true
                    }
                    if (!isReady() || attempt > 0) break
                    Thread.yield()
                }
                synchronized(streamLock) {
                    streamCoordinator.commitRemove(pointerId)
                }
                return false
            }
        }

        override fun tapVirtualPointer(pointerId: Int, xPx: Float, yPx: Float, holdMs: Long) {
            if (upsertVirtualPointer(pointerId, xPx, yPx)) {
                try {
                    Thread.sleep(holdMs.coerceIn(15L, 400L))
                } catch (_: InterruptedException) {
                } finally {
                    removeVirtualPointer(pointerId)
                }
            }
        }

        override fun releaseAllKeymapPointers() {
            synchronized(injectLock) {
                val ids = synchronized(streamLock) {
                    streamCoordinator.activeVirtualIds().filter { it != MACRO_POINTER_ID }
                }
                ids.forEach { removeVirtualPointer(it) }
            }
        }

        private fun injectPlannedEvent(
            planned: PointerStreamCoordinator.PlannedMotionEvent,
            modeOverride: Int? = null
        ): Boolean {
            val mode = modeOverride ?: if (planned.waitForResult) INJECT_MODE_WAIT_FOR_RESULT else INJECT_MODE_ASYNC
            return injectSyntheticEvent(
                downTime = planned.downTime,
                eventTime = planned.eventTime,
                action = planned.action,
                pointers = planned.pointers,
                deviceId = planned.deviceId,
                source = planned.source,
                displayId = planned.displayId,
                mode = mode
            )
        }

        private fun injectSyntheticEvent(
            downTime: Long,
            eventTime: Long,
            action: Int,
            pointers: List<PointerStreamCoordinator.PointerSnapshot>,
            deviceId: Int,
            source: Int,
            displayId: Int,
            mode: Int
        ): Boolean {
            val target = inputInjectorObj ?: return false
            val method = injectInputEventMethod ?: return false
            if (pointers.isEmpty()) return false

            val count = pointers.size
            val props = Array(count) { i ->
                val p = pointers[i]
                MotionEvent.PointerProperties().apply {
                    id = p.id
                    toolType = p.toolType
                }
            }
            val coords = Array(count) { i ->
                val p = pointers[i]
                MotionEvent.PointerCoords().apply {
                    x = p.x
                    y = p.y
                    pressure = p.pressure
                    size = p.size
                    touchMajor = p.touchMajor
                    touchMinor = p.touchMinor
                }
            }

            val ev = MotionEvent.obtain(
                downTime,
                eventTime,
                action,
                count,
                props,
                coords,
                0,
                0,
                1.0f,
                1.0f,
                deviceId,
                0,
                source,
                0
            ) ?: return false

            return try {
                if (displayId >= 0) {
                    setDisplayIdMethod?.invoke(ev, displayId)
                }
                val res = (method.invoke(target, ev, mode) as? Boolean) ?: false
                if (!res && mode == INJECT_MODE_WAIT_FOR_RESULT) {
                    lastInjectFailureDetail =
                        "injectInputEvent=false (action=0x${action.toString(16)}, count=$count, devId=$deviceId, disp=$displayId)"
                    Log.w(DIAG_TAG, lastInjectFailureDetail!!)
                }
                res
            } catch (t: Throwable) {
                val u = unwrap(t)
                val msg = "injectInputEvent ${u.javaClass.simpleName}: ${u.message}"
                lastInjectFailureDetail = msg
                Log.e(DIAG_TAG, msg, u)
                if (u is SecurityException) {
                    markFailed(
                        "Izin INJECT_EVENTS ditolak sistem (di MIUI/HyperOS aktifkan 'Debugging USB - Setelan keamanan'): ${u.message}"
                    )
                }
                false
            } finally {
                ev.recycle()
            }
        }
    }

    init {
        HiddenApiHelper.unlock()
    }

    private val shellLock = Any()
    private val repeatThreadLock = Any()

    private var shellProcess: Process? = null
    private var shellWriter: BufferedWriter? = null
    private var shellReader: BufferedReader? = null

    private val touchInjector by lazy { FrameworkTouchInjector() }
    private val keymapEngine by lazy { LvngShizukuKeymapEngine(touchInjector) }

    @Volatile
    private var warmupStarted = false

    private val repeatGeneration = AtomicLong(0L)
    private val highestStoppedSeq = AtomicLong(0L)
    private var repeatThread: Thread? = null

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        return when (code) {
            TRANSACTION_TAP -> {
                data.enforceInterface(DESCRIPTOR)
                val x = data.readFloat()
                val y = data.readFloat()
                val durationMs = data.readLong()
                val screenW = if (data.dataAvail() >= 12) data.readInt() else 0
                val screenH = if (data.dataAvail() >= 8) data.readInt() else 0
                val rotation = if (data.dataAvail() >= 4) data.readInt() else 0
                val ok = performTap(x, y, durationMs, screenW, screenH, rotation)
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                reply?.writeInt(if (touchInjector.isReady()) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_PING -> {
                data.enforceInterface(DESCRIPTOR)
                triggerAsyncWarmup()
                reply?.writeNoException()
                reply?.writeInt(if (touchInjector.isReady()) 2 else 1)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_DESTROY -> {
                data.enforceInterface(DESCRIPTOR)
                stopRepeatTap()
                keymapEngine.stop()
                touchInjector.stop()
                cleanupShell()
                reply?.writeNoException()
                true
            }

            TRANSACTION_START_REPEAT -> {
                data.enforceInterface(DESCRIPTOR)
                val x = data.readFloat()
                val y = data.readFloat()
                val intervalMs = data.readLong()
                val durationMs = data.readLong()
                val screenW = if (data.dataAvail() >= 12) data.readInt() else 0
                val screenH = if (data.dataAvail() >= 8) data.readInt() else 0
                val rotation = if (data.dataAvail() >= 4) data.readInt() else 0
                val seqId = if (data.dataAvail() >= 8) data.readLong() else 0L
                val ok = startRepeatTap(x, y, intervalMs, durationMs, screenW, screenH, rotation, seqId)
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                reply?.writeInt(if (touchInjector.isReady()) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_STOP_REPEAT -> {
                data.enforceInterface(DESCRIPTOR)
                val seqId = if (data.dataAvail() >= 8) data.readLong() else 0L
                stopRepeatTap(seqId)
                reply?.writeNoException()
                true
            }

            TRANSACTION_SET_SETTING -> {
                data.enforceInterface(DESCRIPTOR)
                val namespace = data.readString().orEmpty()
                val key = data.readString().orEmpty()
                val value = data.readInt()
                val ok = setSystemSetting(namespace, key, value)
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                true
            }

            TRANSACTION_BOOST -> {
                data.enforceInterface(DESCRIPTOR)
                val activeGamePkg = data.readString().orEmpty()
                val callerPkg = data.readString().orEmpty()
                val candidatePkgs = data.createStringArray() ?: emptyArray()
                val boostedCount = performRealDeviceBoost(activeGamePkg, callerPkg, candidatePkgs)
                reply?.writeNoException()
                reply?.writeInt(boostedCount)
                true
            }

            TRANSACTION_IS_REPEAT_ACTIVE -> {
                data.enforceInterface(DESCRIPTOR)
                val isRunning = synchronized(repeatThreadLock) {
                    repeatThread?.isAlive == true && touchInjector.isReady()
                }
                reply?.writeNoException()
                reply?.writeInt(if (isRunning) 1 else 0)
                reply?.writeInt(if (touchInjector.isReady()) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_SET_COMPOSITOR_ACTIVE -> {
                data.enforceInterface(DESCRIPTOR)
                val enabled = data.readInt() == 1
                if (data.dataAvail() >= 4) data.readInt()
                val activeNow = setInjectorActive(enabled)
                reply?.writeNoException()
                reply?.writeInt(if (activeNow) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_IS_COMPOSITOR_ACTIVE -> {
                data.enforceInterface(DESCRIPTOR)
                reply?.writeNoException()
                reply?.writeInt(if (touchInjector.isReady()) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_GET_COMPOSITOR_DIAGNOSTIC -> {
                data.enforceInterface(DESCRIPTOR)
                reply?.writeNoException()
                reply?.writeInt(if (touchInjector.isReady()) 1 else 0)
                reply?.writeString(touchInjector.status)
                reply?.writeString(touchInjector.detail)
                true
            }

            TRANSACTION_SET_KEYMAP_CONFIG -> {
                data.enforceInterface(DESCRIPTOR)
                val configJson = data.readString().orEmpty()
                val screenW = if (data.dataAvail() >= 4) data.readInt() else 0
                val screenH = if (data.dataAvail() >= 4) data.readInt() else 0
                val rotation = if (data.dataAvail() >= 4) data.readInt() else 0
                val captureOnly = if (data.dataAvail() >= 4) data.readInt() == 1 else false
                val callerPkg = if (data.dataAvail() > 0) data.readString().orEmpty() else ""
                val activeNow = keymapEngine.updateConfig(configJson, screenW, screenH, rotation, captureOnly)
                if ((activeNow || captureOnly) && callerPkg.isNotBlank()) {
                    ensureKeyboardAccessibilityBridgeAsync(callerPkg)
                }
                reply?.writeNoException()
                reply?.writeInt(if (activeNow) 1 else 0)
                reply?.writeInt(if (keymapEngine.isAimLocked) 1 else 0)
                reply?.writeString(keymapEngine.inputSummary)
                reply?.writeInt(if (keymapEngine.hasEvdevKeyboard()) 1 else 0)
                reply?.writeInt(if (keymapEngine.hasEvdevMouse()) 1 else 0)
                true
            }

            TRANSACTION_GET_KEYMAP_STATUS -> {
                data.enforceInterface(DESCRIPTOR)
                val (lastKey, lastSeq) = keymapEngine.getLastCapturedKey()
                reply?.writeNoException()
                reply?.writeInt(if (keymapEngine.isAimLocked) 1 else 0)
                reply?.writeString(keymapEngine.inputSummary)
                reply?.writeInt(lastKey)
                reply?.writeLong(lastSeq)
                reply?.writeInt(if (keymapEngine.hasEvdevKeyboard()) 1 else 0)
                reply?.writeInt(if (keymapEngine.hasEvdevMouse()) 1 else 0)
                true
            }

            TRANSACTION_KEYMAP_KEY_EVENT -> {
                data.enforceInterface(DESCRIPTOR)
                val keyCode = data.readInt()
                val isDown = data.readInt() == 1
                keymapEngine.onHostKeyEvent(keyCode, isDown)
                reply?.writeNoException()
                true
            }

            TRANSACTION_KEYMAP_MOUSE_EVENT -> {
                data.enforceInterface(DESCRIPTOR)
                val dx = data.readFloat()
                val dy = data.readFloat()
                val vScroll = data.readFloat()
                val actionMasked = data.readInt()
                val actionButton = data.readInt()
                val buttonState = data.readInt()
                val captureActive = data.readInt() == 1
                keymapEngine.onHostCapturedMouseEvent(
                    dx = dx,
                    dy = dy,
                    vScroll = vScroll,
                    actionMasked = actionMasked,
                    actionButton = actionButton,
                    buttonState = buttonState,
                    isPointerCaptureActive = captureActive
                )
                reply?.writeNoException()
                true
            }

            else -> super.onTransact(code, data, reply, flags)
        }
    }

    private fun triggerAsyncWarmup() {
        if (warmupStarted) return
        warmupStarted = true
        Thread({
            HiddenApiHelper.unlock()
            touchInjector.start()
        }, "LvngInputWarmup").apply {
            isDaemon = true
            start()
        }
    }

    private fun setInjectorActive(enabled: Boolean): Boolean {
        if (!enabled) {
            stopRepeatTap()
            if (!keymapEngine.isActiveEngine()) {
                touchInjector.stop()
            }
            return touchInjector.isReady()
        }
        return touchInjector.start()
    }

    private fun sleepPreciseMs(ms: Long, genCheck: Long? = null) {
        if (ms <= 0L) return
        val deadlineNs = System.nanoTime() + ms * 1_000_000L
        while (true) {
            if (genCheck != null && repeatGeneration.get() != genCheck) return
            val remainingNs = deadlineNs - System.nanoTime()
            if (remainingNs <= 0L) return
            LockSupport.parkNanos(remainingNs.coerceAtMost(5_000_000L))
        }
    }

    @Suppress("UNUSED_PARAMETER")
    private fun performTap(
        x: Float,
        y: Float,
        durationMs: Long,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Boolean {
        if (screenW <= 0 || screenH <= 0) return false
        val safeX = x.coerceIn(1f, screenW.toFloat())
        val safeY = y.coerceIn(1f, screenH.toFloat())
        val holdMs = durationMs.coerceIn(14L, 400L)

        if (!touchInjector.isReady() && !touchInjector.start()) {
            return false
        }
        return touchInjector.tapOnce(safeX, safeY, holdMs, null)
    }

    @Suppress("UNUSED_PARAMETER")
    private fun startRepeatTap(
        x: Float,
        y: Float,
        intervalMs: Long,
        durationMs: Long,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        seqId: Long = 0L
    ): Boolean {
        if (screenW <= 0 || screenH <= 0) return false
        val safeX = x.coerceIn(1f, screenW.toFloat())
        val safeY = y.coerceIn(1f, screenH.toFloat())
        val clampedInterval = intervalMs.coerceIn(10L, 1000L)
        // Human-like crisp tap pulse: keep touch-down brief (10-26ms) and always lift cleanly
        // between cycles so games treat Target as discrete taps rather than a held button.
        val effectiveHoldMs = when {
            clampedInterval <= 80L -> durationMs.coerceIn(10L, 16L)
            clampedInterval <= 160L -> durationMs.coerceIn(10L, 22L)
            else -> durationMs.coerceIn(12L, 28L)
        }
        val effectiveGapMs = clampedInterval.coerceAtLeast(24L)

        if (!touchInjector.isReady() && !touchInjector.start()) {
            return false
        }
        touchInjector.ensureMonitorOpen()

        synchronized(repeatThreadLock) {
            if (seqId > 0L && seqId <= highestStoppedSeq.get()) {
                return false
            }

            val myGen = repeatGeneration.incrementAndGet()
            repeatThread?.let { prev ->
                LockSupport.unpark(prev)
                prev.interrupt()
                runCatching { prev.join(180L) }
            }

            val worker = Thread({
                try {
                    runCatching {
                        AndroidProcess.setThreadPriority(AndroidProcess.THREAD_PRIORITY_URGENT_DISPLAY)
                    }

                    touchInjector.setMacroLoopActive(true)
                    while (repeatGeneration.get() == myGen && !Thread.currentThread().isInterrupted) {
                        if (!touchInjector.isReady()) {
                            Log.e(
                                DIAG_TAG,
                                "LvngMacroLoop dihentikan (${touchInjector.status}: ${touchInjector.detail})"
                            )
                            break
                        }
                        val tapped = touchInjector.tapOnce(safeX, safeY, effectiveHoldMs, myGen)
                        if (!tapped && !touchInjector.isReady()) {
                            break
                        }

                        if (repeatGeneration.get() != myGen) break
                        sleepPreciseMs(effectiveGapMs, myGen)
                    }
                } finally {
                    touchInjector.releaseMacroIfActive()
                    synchronized(repeatThreadLock) {
                        if (repeatThread === Thread.currentThread()) {
                            repeatThread = null
                        }
                        // Matikan flag hanya jika tidak ada worker baru yang sudah menggantikan.
                        if (repeatThread == null) {
                            touchInjector.setMacroLoopActive(false)
                        }
                    }
                }
            }, "LvngMacroLoop").apply {
                priority = Thread.MAX_PRIORITY
                isDaemon = true
            }
            repeatThread = worker
            worker.start()
        }
        return true
    }

    private fun stopRepeatTap(seqId: Long = 0L) {
        synchronized(repeatThreadLock) {
            if (seqId > 0L) {
                while (true) {
                    val prev = highestStoppedSeq.get()
                    if (seqId <= prev || highestStoppedSeq.compareAndSet(prev, seqId)) break
                }
            }
            repeatGeneration.incrementAndGet()
            repeatThread?.let { thread ->
                LockSupport.unpark(thread)
                thread.interrupt()
                runCatching { thread.join(180L) }
            }
            repeatThread = null
            touchInjector.setMacroLoopActive(false)
            touchInjector.releaseMacroIfActive()
        }
    }

    @Volatile
    private var lastBridgeCheckAtMs: Long = 0L

    private fun ensureKeyboardAccessibilityBridgeAsync(callerPkg: String) {
        val safePkg = callerPkg.trim()
        if (!safePkg.matches(Regex("[a-zA-Z0-9_.]+"))) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastBridgeCheckAtMs < 5_000L) return
        lastBridgeCheckAtMs = now
        Thread({
            val svc = "$safePkg/com.example.input.LvngKeyboardBridgeService"
            runShellBatch(
                listOf(
                    "cur=\$(settings get secure enabled_accessibility_services 2>/dev/null); " +
                        "case \":\$cur:\" in *\":$svc:\"*) ;; *) " +
                        "if [ -z \"\$cur\" ] || [ \"\$cur\" = \"null\" ]; then " +
                        "settings put secure enabled_accessibility_services \"$svc\"; " +
                        "else " +
                        "settings put secure enabled_accessibility_services \"\$cur:$svc\"; " +
                        "fi;; esac",
                    "settings put secure accessibility_enabled 1"
                )
            )
        }, "LvngBridgeEnable").apply {
            isDaemon = true
            start()
        }
    }

    private fun setSystemSetting(namespace: String, key: String, value: Int): Boolean {
        val safeNs = when (namespace) {
            "system", "secure", "global" -> namespace
            else -> return false
        }
        val allowedKeys = setOf("show_touches", "pointer_location", "accelerometer_rotation")
        if (key !in allowedKeys) return false
        val safeVal = if (value != 0) 1 else 0
        val out = runShellBatch(listOf("settings put $safeNs $key $safeVal"))
        return out != null
    }

    private fun performRealDeviceBoost(
        activeGamePackage: String,
        callerPackage: String,
        candidatePackages: Array<String>
    ): Int {
        val protectedExact = HashSet<String>().apply {
            add("android")
            add("com.android.systemui")
            add("com.android.phone")
            add("com.android.bluetooth")
            add("com.android.settings")
            add("com.google.android.gms")
            add("com.google.android.gsf")
            add("moe.shizuku.privileged.api")
            if (callerPackage.isNotBlank()) add(callerPackage)
            if (activeGamePackage.isNotBlank()) add(activeGamePackage)
        }

        val envInfo = runShellBatch(
            listOf(
                "cmd package resolve-activity --brief -c android.intent.category.HOME 2>/dev/null | tail -n 1",
                "settings get secure default_input_method 2>/dev/null"
            )
        ).orEmpty()

        envInfo.forEach { line ->
            val pkg = line.trim().substringBefore('/').trim()
            if (pkg.contains('.') && !pkg.contains(' ')) {
                protectedExact.add(pkg)
            }
        }

        val sanitizedTargets = candidatePackages
            .map { it.trim() }
            .filter { pkg ->
                pkg.isNotBlank() &&
                    pkg !in protectedExact &&
                    pkg.matches(Regex("[a-zA-Z0-9_\\.]+"))
            }
            .distinct()
            .take(60)

        val commands = mutableListOf<String>()
        commands.add("am kill-all 2>/dev/null")
        sanitizedTargets.forEach { pkg ->
            commands.add("am send-trim-memory $pkg COMPLETE 2>/dev/null; am kill $pkg 2>/dev/null")
        }
        commands.add("pm trim-caches 1024M 2>/dev/null")
        commands.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null")
        commands.add("sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null")

        runShellBatch(commands)
        return sanitizedTargets.size
    }

    private fun ensureShellLocked(): Boolean {
        val proc = shellProcess
        if (proc != null && proc.isAlive && shellWriter != null && shellReader != null) {
            return true
        }
        cleanupShellLocked()
        return runCatching {
            val started = ProcessBuilder("sh").redirectErrorStream(true).start()
            shellProcess = started
            shellWriter = BufferedWriter(OutputStreamWriter(started.outputStream))
            shellReader = BufferedReader(InputStreamReader(started.inputStream))
            true
        }.getOrElse {
            cleanupShellLocked()
            false
        }
    }

    private fun runShellBatch(commands: List<String>): List<String>? {
        val marker = "__LVNG_DONE_${System.nanoTime()}__"
        synchronized(shellLock) {
            if (!ensureShellLocked()) return null
            return runCatching {
                val writer = shellWriter!!
                val reader = shellReader!!
                commands.forEach { cmd ->
                    writer.write(cmd)
                    writer.newLine()
                }
                writer.write("echo $marker")
                writer.newLine()
                writer.flush()

                val lines = mutableListOf<String>()
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line == marker) break
                    lines.add(line)
                }
                lines
            }.getOrElse {
                cleanupShellLocked()
                null
            }
        }
    }

    private fun cleanupShell() {
        synchronized(shellLock) {
            cleanupShellLocked()
        }
    }

    private fun cleanupShellLocked() {
        runCatching { shellWriter?.close() }
        runCatching { shellReader?.close() }
        runCatching { shellProcess?.destroy() }
        shellWriter = null
        shellReader = null
        shellProcess = null
    }

    companion object {
        const val DESCRIPTOR = "com.example.shizuku.ILvngInputService"
        const val TRANSACTION_TAP = IBinder.FIRST_CALL_TRANSACTION + 1
        const val TRANSACTION_PING = IBinder.FIRST_CALL_TRANSACTION + 2
        const val TRANSACTION_DESTROY = IBinder.FIRST_CALL_TRANSACTION + 3
        const val TRANSACTION_START_REPEAT = IBinder.FIRST_CALL_TRANSACTION + 4
        const val TRANSACTION_STOP_REPEAT = IBinder.FIRST_CALL_TRANSACTION + 5
        const val TRANSACTION_SET_SETTING = IBinder.FIRST_CALL_TRANSACTION + 6
        const val TRANSACTION_BOOST = IBinder.FIRST_CALL_TRANSACTION + 7
        const val TRANSACTION_IS_REPEAT_ACTIVE = IBinder.FIRST_CALL_TRANSACTION + 8
        const val TRANSACTION_SET_COMPOSITOR_ACTIVE = IBinder.FIRST_CALL_TRANSACTION + 9
        const val TRANSACTION_IS_COMPOSITOR_ACTIVE = IBinder.FIRST_CALL_TRANSACTION + 10
        const val TRANSACTION_GET_COMPOSITOR_DIAGNOSTIC = IBinder.FIRST_CALL_TRANSACTION + 11
        const val TRANSACTION_SET_KEYMAP_CONFIG = IBinder.FIRST_CALL_TRANSACTION + 12
        const val TRANSACTION_GET_KEYMAP_STATUS = IBinder.FIRST_CALL_TRANSACTION + 13
        const val TRANSACTION_KEYMAP_KEY_EVENT = IBinder.FIRST_CALL_TRANSACTION + 14
        const val TRANSACTION_KEYMAP_MOUSE_EVENT = IBinder.FIRST_CALL_TRANSACTION + 15

        private const val DIAG_TAG = "LvngTouchInjector"
        private const val MAX_SOLO_SKIPS = 3
        const val COMPOSITOR_STOPPED = "STOPPED"
        const val COMPOSITOR_STARTING = "STARTING"
        const val COMPOSITOR_GRABBED = "GRABBED"
        const val COMPOSITOR_FAILED = "FAILED"

        const val MACRO_POINTER_ID = PointerStreamCoordinator.MACRO_POINTER_ID
        private const val LEGACY_VIRTUAL_NAME = "LVNG Virtual Touch"

        private const val INJECT_MODE_ASYNC = 0
        private const val INJECT_MODE_WAIT_FOR_RESULT = 1

        private fun unwrap(t: Throwable): Throwable {
            return if (t is InvocationTargetException) (t.targetException ?: t) else t
        }
    }
}
