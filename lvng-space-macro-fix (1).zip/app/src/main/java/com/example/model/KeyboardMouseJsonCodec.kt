package com.example.model

import org.json.JSONArray
import org.json.JSONObject

object KeyboardMouseJsonCodec {
    fun encode(config: KeyboardMouseConfig): JSONObject {
        val nodesArr = JSONArray()
        config.nodes.forEach { n ->
            nodesArr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("name", n.name)
                    put("type", n.type.id)
                    put("keyCode", n.keyCode)
                    put("x", n.xFraction.toDouble())
                    put("y", n.yFraction.toDouble())
                    put("radius", n.radiusFraction.toDouble())
                    put("behavior", n.triggerBehavior.id)
                    put("holdMs", n.holdTapDurationMs)
                    put("wasdUp", n.wasdUpKeyCode)
                    put("wasdLeft", n.wasdLeftKeyCode)
                    put("wasdDown", n.wasdDownKeyCode)
                    put("wasdRight", n.wasdRightKeyCode)
                }
            )
        }
        val t = config.tweaks
        val tweaksObj = JSONObject().apply {
            put("sensX", t.sensitivityX.toDouble())
            put("sensY", t.sensitivityY.toDouble())
            put("accel", t.acceleration.toDouble())
            put("smooth", t.smoothing.toDouble())
            put("deadzone", t.deadzonePx.toDouble())
            put("invertY", t.invertY)
            put("resetRadius", t.aimResetRadiusFraction.toDouble())
            put("toggleKey", t.cursorToggleKeyCode)
            put("autoLock", t.autoLockAimOnEnable)
            put("showHints", t.showKeyHintsOverlay)
            put("opacity", t.overlayOpacity.toDouble())
            put("aimPanInternalTweak", MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK)
        }
        return JSONObject().apply {
            put("schemaVersion", 2)
            put("active", config.isActive)
            put("nodes", nodesArr)
            put("tweaks", tweaksObj)
        }
    }

    fun encodeToString(config: KeyboardMouseConfig): String = encode(config).toString()

    fun decode(jsonStr: String?): KeyboardMouseConfig {
        if (jsonStr.isNullOrBlank()) return KeyboardMouseConfig()
        return runCatching {
            val root = JSONObject(jsonStr)
            val schemaVer = root.optInt("schemaVersion", 1)
            val nodesArr = root.optJSONArray("nodes")
            val nodes = if (nodesArr != null) {
                (0 until nodesArr.length()).mapNotNull { i ->
                    val o = nodesArr.optJSONObject(i) ?: return@mapNotNull null
                    KeyboardMouseNode(
                        id = o.optString("id", "km_${i + 1}"),
                        name = o.optString("name", "KEY ${i + 1}"),
                        type = KeymapActionType.fromId(o.optString("type", KeymapActionType.KEY_TAP.id)),
                        keyCode = o.optInt("keyCode", android.view.KeyEvent.KEYCODE_UNKNOWN),
                        xFraction = o.optDouble("x", 0.5).toFloat().coerceIn(0.02f, 0.98f),
                        yFraction = o.optDouble("y", 0.5).toFloat().coerceIn(0.03f, 0.97f),
                        radiusFraction = o.optDouble("radius", 0.095).toFloat().coerceIn(0.04f, 0.35f),
                        triggerBehavior = KeyTriggerBehavior.fromId(o.optString("behavior", KeyTriggerBehavior.HOLD.id)),
                        holdTapDurationMs = o.optInt("holdMs", 45).coerceIn(15, 500),
                        wasdUpKeyCode = o.optInt("wasdUp", android.view.KeyEvent.KEYCODE_W),
                        wasdLeftKeyCode = o.optInt("wasdLeft", android.view.KeyEvent.KEYCODE_A),
                        wasdDownKeyCode = o.optInt("wasdDown", android.view.KeyEvent.KEYCODE_S),
                        wasdRightKeyCode = o.optInt("wasdRight", android.view.KeyEvent.KEYCODE_D)
                    )
                }
            } else {
                defaultKeyboardMouseNodes()
            }

            val t = root.optJSONObject("tweaks")
            val tweaks = if (t != null) {
                val rawToggle = t.optInt("toggleKey", android.view.KeyEvent.KEYCODE_F1)
                val migratedToggle = resolveMigratedToggleKey(schemaVer, rawToggle)
                MouseTweaksConfig(
                    sensitivityX = t.optDouble("sensX", 1.60).toFloat().coerceIn(0.1f, 10.0f),
                    sensitivityY = t.optDouble("sensY", 1.40).toFloat().coerceIn(0.1f, 10.0f),
                    acceleration = t.optDouble("accel", 0.0).toFloat().coerceIn(0f, 1.5f),
                    smoothing = t.optDouble("smooth", 0.18).toFloat().coerceIn(0f, 0.85f),
                    deadzonePx = t.optDouble("deadzone", 0.0).toFloat().coerceIn(0f, 5.0f),
                    invertY = t.optBoolean("invertY", false),
                    aimResetRadiusFraction = t.optDouble("resetRadius", 0.42).toFloat().coerceIn(0.10f, 0.48f),
                    cursorToggleKeyCode = migratedToggle,
                    autoLockAimOnEnable = t.optBoolean("autoLock", true),
                    showKeyHintsOverlay = t.optBoolean("showHints", true),
                    overlayOpacity = t.optDouble("opacity", 0.85).toFloat().coerceIn(0.15f, 1.0f),
                    aimPanInternalTweak = MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK
                )
            } else {
                MouseTweaksConfig()
            }

            KeyboardMouseConfig(
                nodes = nodes,
                tweaks = tweaks,
                isActive = root.optBoolean("active", false)
            )
        }.getOrElse { KeyboardMouseConfig() }
    }

    internal fun resolveMigratedToggleKey(schemaVersion: Int, rawToggleKeyCode: Int): Int {
        return if (schemaVersion < 2 && rawToggleKeyCode == android.view.KeyEvent.KEYCODE_GRAVE) {
            android.view.KeyEvent.KEYCODE_F1
        } else {
            rawToggleKeyCode
        }
    }
}
