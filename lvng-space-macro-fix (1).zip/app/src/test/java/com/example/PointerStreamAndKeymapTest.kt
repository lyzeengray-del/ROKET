package com.example

import android.view.KeyEvent
import android.view.MotionEvent
import com.example.model.KeyTriggerBehavior
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseNode
import com.example.model.KeymapActionType
import com.example.model.MouseTweaksConfig
import com.example.shizuku.LvngKeyCodes
import com.example.shizuku.LvngShizukuKeymapEngine
import com.example.shizuku.PointerStreamCoordinator
import com.example.shizuku.VirtualPointerHost
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PointerStreamAndKeymapTest {

    private class RecordingVirtualPointerHost : VirtualPointerHost {
        val coordinator = PointerStreamCoordinator()
        val emittedEvents = mutableListOf<PointerStreamCoordinator.PlannedMotionEvent>()
        private var timeCursor = 1000L

        private fun nextTime(): Long {
            timeCursor += 5L
            return timeCursor
        }

        fun injectPhysicalDown(id: Int, x: Float, y: Float, downTime: Long = 500L) {
            val snap = coordinator.activePhysicalIds().map { pid ->
                PointerStreamCoordinator.fingerPointer(pid, 100f, 100f)
            } + PointerStreamCoordinator.fingerPointer(id, x, y)
            val action = if (snap.size == 1) {
                PointerStreamCoordinator.ACTION_DOWN
            } else {
                PointerStreamCoordinator.ACTION_POINTER_DOWN or
                    ((snap.size - 1) shl PointerStreamCoordinator.ACTION_POINTER_INDEX_SHIFT)
            }
            coordinator.onPhysicalEvent(
                actionMasked = action and 0xFF,
                actionIndex = snap.size - 1,
                downTime = downTime,
                deviceId = 7,
                source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
                displayId = 0,
                eventPointers = snap
            )
        }

        override fun ensureInjectorStarted(): Boolean = true

        override fun upsertVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean {
            return when (val plan = coordinator.planUpsert(pointerId, xPx, yPx, nextTime(), 7)) {
                is PointerStreamCoordinator.UpsertPlan.MoveExisting -> {
                    emittedEvents.add(plan.event)
                    true
                }
                is PointerStreamCoordinator.UpsertPlan.JoinOrDown -> {
                    emittedEvents.add(plan.event)
                    coordinator.commitUpsert(plan)
                    true
                }
            }
        }

        override fun moveVirtualPointer(pointerId: Int, xPx: Float, yPx: Float): Boolean {
            val ev = coordinator.planMove(pointerId, xPx, yPx, nextTime(), 7) ?: return false
            emittedEvents.add(ev)
            return true
        }

        override fun removeVirtualPointer(pointerId: Int): Boolean {
            val ev = coordinator.removeVirtual(pointerId, nextTime(), 7) ?: return false
            emittedEvents.add(ev)
            return true
        }

        override fun tapVirtualPointer(pointerId: Int, xPx: Float, yPx: Float, holdMs: Long) {
            if (upsertVirtualPointer(pointerId, xPx, yPx)) {
                removeVirtualPointer(pointerId)
            }
        }

        override fun releaseAllKeymapPointers() {
            coordinator.activeVirtualIds()
                .filter { it != PointerStreamCoordinator.MACRO_POINTER_ID }
                .forEach { removeVirtualPointer(it) }
        }
    }

    private fun testConfig(): KeyboardMouseConfig {
        return KeyboardMouseConfig(
            isActive = true,
            tweaks = MouseTweaksConfig(
                sensitivityX = 1.0f,
                sensitivityY = 1.0f,
                acceleration = 0f,
                smoothing = 0f,
                deadzonePx = 0f,
                invertY = false,
                cursorToggleKeyCode = KeyEvent.KEYCODE_F1,
                autoLockAimOnEnable = true
            ),
            nodes = listOf(
                KeyboardMouseNode(
                    id = "wasd_1",
                    name = "Joystick",
                    type = KeymapActionType.WASD_JOYSTICK,
                    xFraction = 0.2f,
                    yFraction = 0.7f,
                    radiusFraction = 0.10f
                ),
                KeyboardMouseNode(
                    id = "look_1",
                    name = "FPS Look",
                    type = KeymapActionType.MOUSE_AIM,
                    xFraction = 0.65f,
                    yFraction = 0.45f
                ),
                KeyboardMouseNode(
                    id = "aimpan_1",
                    name = "AimPan",
                    type = KeymapActionType.AIM_PAN,
                    keyCode = LvngKeyCodes.MOUSE_LEFT,
                    xFraction = 0.85f,
                    yFraction = 0.75f
                ),
                KeyboardMouseNode(
                    id = "key_f",
                    name = "F",
                    type = KeymapActionType.KEY_TAP,
                    keyCode = KeyEvent.KEYCODE_F,
                    xFraction = 0.75f,
                    yFraction = 0.55f,
                    triggerBehavior = KeyTriggerBehavior.HOLD
                ),
                KeyboardMouseNode(
                    id = "key_r",
                    name = "R",
                    type = KeymapActionType.KEY_TAP,
                    keyCode = KeyEvent.KEYCODE_R,
                    xFraction = 0.70f,
                    yFraction = 0.50f,
                    triggerBehavior = KeyTriggerBehavior.HOLD
                )
            )
        )
    }

    private fun newEngine(host: RecordingVirtualPointerHost, cfg: KeyboardMouseConfig = testConfig()): LvngShizukuKeymapEngine {
        val engine = LvngShizukuKeymapEngine(host, runDirectInTests = true)
        assertTrue(engine.updateParsedConfig(cfg, screenW = 1000, screenH = 1000, rotation = 0, skipReaders = true))
        return engine
    }

    @Test
    fun aimPanInternalTweak_isLockedAt16450AndDoesNotMutateSensitivity() {
        assertEquals(16450, MouseTweaksConfig.AIM_PAN_INTERNAL_TWEAK)
        assertEquals(16450, LvngShizukuKeymapEngine.AIM_PAN_INTERNAL_TWEAK)

        val host = RecordingVirtualPointerHost()
        val tampered = testConfig().copy(
            tweaks = testConfig().tweaks.copy(aimPanInternalTweak = 999)
        )
        val engine = newEngine(host, tampered)
        assertEquals(16450, engine.config.tweaks.aimPanInternalTWEAKCheck())

        // Hold LMB on AimPan at (850, 750) then move mouse by dx=+10, dy=-25 with sensitivity=1.0, accel=0, smooth=0
        engine.onHostKeyEvent(LvngKeyCodes.MOUSE_LEFT, isDown = true)
        engine.onHostCapturedMouseEvent(
            dx = 10f,
            dy = -25f,
            vScroll = 0f,
            actionMasked = MotionEvent.ACTION_MOVE,
            actionButton = 0,
            buttonState = 0,
            isPointerCaptureActive = true
        )

        val moved = host.emittedEvents.last()
        assertEquals(PointerStreamCoordinator.ACTION_MOVE, moved.action)
        val aimPanPtr = moved.pointers.first { it.id == PointerStreamCoordinator.AIM_PAN_POINTER_ID }
        // Exact 1:1 sensitivity=1.0 -> 850 + 10 = 860, 750 - 25 = 725 (not scaled by 1.645x!)
        assertEquals(860f, aimPanPtr.x, 0.01f)
        assertEquals(725f, aimPanPtr.y, 0.01f)
    }

    private fun MouseTweaksConfig.aimPanInternalTWEAKCheck(): Int = aimPanInternalTweak

    @Test
    fun pointerIdAllocation_neverOverlapsPhysicalOrReservedSlots() {
        val assigned = LinkedHashMap<String, Int>()
        val slots = (1..13).map { i ->
            PointerStreamCoordinator.allocateSentuhSlot("node_$i", assigned)
        }
        assertEquals(13, slots.distinct().size)
        slots.forEach { slot ->
            assertTrue("Slot $slot must be in Sentuh range 19..31", slot in 19..31)
            assertTrue(slot > PointerStreamCoordinator.MAX_PHYSICAL_POINTER_ID)
            assertNotEquals(PointerStreamCoordinator.MACRO_POINTER_ID, slot)
            assertNotEquals(PointerStreamCoordinator.WASD_POINTER_ID, slot)
            assertNotEquals(PointerStreamCoordinator.MOUSE_AIM_POINTER_ID, slot)
            assertNotEquals(PointerStreamCoordinator.AIM_PAN_POINTER_ID, slot)
        }
    }

    @Test
    fun scenario1_persistentJoystickHeldWhilePressingWAndS_andPhysicalJoystick() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)

        // Part A: Virtual WASD joystick held with W, then S (canceling vector to 0), then D right
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))

        host.emittedEvents.clear()
        engine.onHostKeyEvent(KeyEvent.KEYCODE_S, isDown = true)
        assertTrue("WASD slot 16 must remain active when W+S are both held", host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertTrue("No ACTION_UP may be emitted while W+S held", host.emittedEvents.none { it.action == PointerStreamCoordinator.ACTION_UP || it.action == PointerStreamCoordinator.ACTION_CANCEL })
        assertTrue(host.emittedEvents.any { it.action == PointerStreamCoordinator.ACTION_MOVE })

        // Steer right with D while W+S are still held
        engine.onHostKeyEvent(KeyEvent.KEYCODE_D, isDown = true)
        val afterD = host.emittedEvents.last()
        assertEquals(PointerStreamCoordinator.ACTION_MOVE, afterD.action)
        val wasdRight = afterD.pointers.first { it.id == PointerStreamCoordinator.WASD_POINTER_ID }
        assertTrue("WASD X should move right of center (200)", wasdRight.x > 250f)

        // Release S and W one by one -> D still held -> slot 16 MUST stay down
        engine.onHostKeyEvent(KeyEvent.KEYCODE_S, isDown = false)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = false)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertTrue(host.emittedEvents.none { it.action == PointerStreamCoordinator.ACTION_UP || it.action == PointerStreamCoordinator.ACTION_CANCEL })

        // Release final directional key D -> NOW slot 16 releases with ACTION_UP
        engine.onHostKeyEvent(KeyEvent.KEYCODE_D, isDown = false)
        assertFalse(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertEquals(PointerStreamCoordinator.ACTION_UP, host.emittedEvents.last().action)

        // Part B: Physical joystick (id=0) held while pressing W, S, and releasing them
        host.emittedEvents.clear()
        host.injectPhysicalDown(id = 0, x = 180f, y = 720f, downTime = 500L)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_S, isDown = true)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = false)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_S, isDown = false)

        assertTrue("Physical joystick finger 0 must stay untouched", host.coordinator.activePhysicalIds().contains(0))
        assertTrue("Zero ACTION_UP or ACTION_CANCEL allowed while physical finger 0 is held", host.emittedEvents.none {
            it.action == PointerStreamCoordinator.ACTION_UP || it.action == PointerStreamCoordinator.ACTION_CANCEL
        })
        assertTrue("Virtual lift must use ACTION_POINTER_UP", (host.emittedEvents.last().action and 0xFF) == PointerStreamCoordinator.ACTION_POINTER_UP)
        assertTrue(host.emittedEvents.all { ev -> ev.pointers.any { it.id == 0 } })
    }

    @Test
    fun scenario2And3_joystickHeldWhileUsingAimPanAndDraggingLmbFire() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)

        // Hold W on joystick
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        // Hold LMB on AimPan
        engine.onHostKeyEvent(LvngKeyCodes.MOUSE_LEFT, isDown = true)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.AIM_PAN_POINTER_ID))

        val joinEvent = host.emittedEvents.last()
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_DOWN, joinEvent.action and 0xFF)
        assertTrue(joinEvent.pointers.any { it.id == PointerStreamCoordinator.WASD_POINTER_ID })
        assertTrue(joinEvent.pointers.any { it.id == PointerStreamCoordinator.AIM_PAN_POINTER_ID })

        // Drag upward multiple ticks while shooting
        engine.onHostCapturedMouseEvent(0f, -30f, 0f, MotionEvent.ACTION_MOVE, 0, 0, isPointerCaptureActive = true)
        engine.onHostCapturedMouseEvent(5f, -40f, 0f, MotionEvent.ACTION_MOVE, 0, 0, isPointerCaptureActive = true)

        val dragEvent = host.emittedEvents.last()
        assertEquals(PointerStreamCoordinator.ACTION_MOVE, dragEvent.action)
        val firePtr = dragEvent.pointers.first { it.id == PointerStreamCoordinator.AIM_PAN_POINTER_ID }
        assertEquals(855f, firePtr.x, 0.01f)
        assertEquals(680f, firePtr.y, 0.01f)
        assertTrue("Joystick 16 must remain present in drag-shot move events", dragEvent.pointers.any { it.id == PointerStreamCoordinator.WASD_POINTER_ID })

        // Release LMB -> ONLY slot 18 lifts via ACTION_POINTER_UP, joystick 16 remains active!
        engine.onHostKeyEvent(LvngKeyCodes.MOUSE_LEFT, isDown = false)
        assertFalse(host.coordinator.isVirtualActive(PointerStreamCoordinator.AIM_PAN_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, host.emittedEvents.last().action and 0xFF)
    }

    @Test
    fun scenario4_joystickPhysicalAndVirtualHeldWhileMacroRuns() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)

        // Hold both physical joystick (id=0) and virtual joystick (id=16)
        host.injectPhysicalDown(id = 0, x = 150f, y = 700f, downTime = 777L)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        host.emittedEvents.clear()

        // Execute 5 repeated Macro taps on slot 15
        repeat(5) {
            host.tapVirtualPointer(PointerStreamCoordinator.MACRO_POINTER_ID, 850f, 650f, 35L)
        }

        assertEquals(10, host.emittedEvents.size)
        host.emittedEvents.forEachIndexed { idx, ev ->
            assertEquals("Physical downTime must stay intact across macro cycles", 777L, ev.downTime)
            assertTrue("Physical finger 0 must always be present", ev.pointers.any { it.id == 0 })
            assertTrue("Virtual WASD 16 must always be present", ev.pointers.any { it.id == PointerStreamCoordinator.WASD_POINTER_ID })
            val masked = ev.action and 0xFF
            if (idx % 2 == 0) {
                assertEquals(PointerStreamCoordinator.ACTION_POINTER_DOWN, masked)
            } else {
                assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, masked)
            }
            assertNotEquals(PointerStreamCoordinator.ACTION_UP, masked)
            assertNotEquals(PointerStreamCoordinator.ACTION_CANCEL, masked)
        }
        assertTrue(host.coordinator.hasPhysicalContacts())
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertFalse(host.coordinator.isVirtualActive(PointerStreamCoordinator.MACRO_POINTER_ID))
    }

    @Test
    fun scenario5_multiButtonSequentialRelease_emitsFullActionUpOnlyAtZeroContacts() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)

        // Press W (16), LMB AimPan (18), F (19), R (20)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        engine.onHostKeyEvent(LvngKeyCodes.MOUSE_LEFT, isDown = true)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_F, isDown = true)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_R, isDown = true)
        assertEquals(4, host.coordinator.activeVirtualCount())

        // Release F -> ACTION_POINTER_UP (3 remain)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_F, isDown = false)
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, host.emittedEvents.last().action and 0xFF)
        assertEquals(3, host.coordinator.activeVirtualCount())

        // Release LMB -> ACTION_POINTER_UP (2 remain)
        engine.onHostKeyEvent(LvngKeyCodes.MOUSE_LEFT, isDown = false)
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, host.emittedEvents.last().action and 0xFF)
        assertEquals(2, host.coordinator.activeVirtualCount())

        // Release R -> ACTION_POINTER_UP (1 remains: WASD 16)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_R, isDown = false)
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, host.emittedEvents.last().action and 0xFF)
        assertEquals(1, host.coordinator.activeVirtualCount())
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))

        // Release W -> ONLY NOW remaining == 0 -> full ACTION_UP
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = false)
        assertEquals(PointerStreamCoordinator.ACTION_UP, host.emittedEvents.last().action)
        assertEquals(0, host.coordinator.activeVirtualCount())
    }

    @Test
    fun f1Toggle_locksAndUnlocksMouseOnlyWithoutInterruptingJoystickOrKeys() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)
        assertTrue(engine.isAimLocked)

        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        engine.onHostCapturedMouseEvent(20f, 0f, 0f, MotionEvent.ACTION_MOVE, 0, 0, isPointerCaptureActive = true)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.MOUSE_AIM_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))

        // Press F1 -> unlocks mouse, releases slot 17 via ACTION_POINTER_UP, keeps WASD slot 16 alive
        engine.onHostKeyEvent(KeyEvent.KEYCODE_F1, isDown = true)
        assertFalse(engine.isAimLocked)
        assertFalse(host.coordinator.isVirtualActive(PointerStreamCoordinator.MOUSE_AIM_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertNotEquals(PointerStreamCoordinator.ACTION_UP, host.emittedEvents.last().action)

        // Press F1 again -> relocks mouse while WASD continues uninterrupted
        engine.onHostKeyEvent(KeyEvent.KEYCODE_F1, isDown = true)
        assertTrue(engine.isAimLocked)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
    }

    @Test
    fun nonPreemptionRule_failedJoinNeverClearsPhysicalOrVirtualStream() {
        val coordinator = PointerStreamCoordinator()
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_DOWN,
            actionIndex = 0,
            downTime = 1234L,
            deviceId = 5,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(PointerStreamCoordinator.fingerPointer(0, 120f, 650f))
        )
        val wasdJoin = coordinator.planUpsert(PointerStreamCoordinator.WASD_POINTER_ID, 200f, 700f, 1240L, 5)
            as PointerStreamCoordinator.UpsertPlan.JoinOrDown
        assertFalse(wasdJoin.isFreshDown)
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_DOWN, wasdJoin.event.action and 0xFF)
        coordinator.commitUpsert(wasdJoin)

        // Attempt Macro join -> MUST produce ACTION_POINTER_DOWN, never ACTION_DOWN
        val macroJoin = coordinator.planUpsert(PointerStreamCoordinator.MACRO_POINTER_ID, 850f, 600f, 1250L, 5)
            as PointerStreamCoordinator.UpsertPlan.JoinOrDown
        assertFalse(macroJoin.isFreshDown)
        assertEquals(PointerStreamCoordinator.ACTION_POINTER_DOWN, macroJoin.event.action and 0xFF)
        assertNotNull(coordinator.activePhysicalIds().firstOrNull())
        assertTrue(coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
    }

    @Test
    fun slowMicroGlide_passesZeroDeadzoneAndGlidesSmoothlyWithoutDroppingCounts() {
        val host = RecordingVirtualPointerHost()
        val cfg = testConfig().copy(
            tweaks = MouseTweaksConfig(
                sensitivityX = 1.0f,
                sensitivityY = 1.0f,
                acceleration = 0f,
                smoothing = 0f,
                deadzonePx = 0f,
                invertY = false
            )
        )
        val engine = newEngine(host, cfg)

        // 8 slow micro-glides of 0.25px each -> total exactly +2.0px X, +1.0px Y
        repeat(8) {
            engine.onHostCapturedMouseEvent(
                dx = 0.25f,
                dy = 0.125f,
                vScroll = 0f,
                actionMasked = MotionEvent.ACTION_MOVE,
                actionButton = 0,
                buttonState = 0,
                isPointerCaptureActive = true
            )
        }

        val lastAim = host.emittedEvents.last().pointers.first {
            it.id == PointerStreamCoordinator.MOUSE_AIM_POINTER_ID
        }
        assertEquals(652.0f, lastAim.x, 0.01f)
        assertEquals(451.0f, lastAim.y, 0.01f)
    }

    @Test
    fun sensitivityXYAndZeroLossSmoothing_scaleIndependentlyAndDrain100Percent() {
        val host = RecordingVirtualPointerHost()
        val cfg = testConfig().copy(
            tweaks = MouseTweaksConfig(
                sensitivityX = 3.5f,
                sensitivityY = 1.5f,
                acceleration = 0f,
                smoothing = 0.50f,
                deadzonePx = 0f,
                invertY = false
            )
        )
        val engine = newEngine(host, cfg)

        // Single move dx=+10, dy=+10 -> scaled target +35x, +15y
        engine.onHostCapturedMouseEvent(
            dx = 10f,
            dy = 10f,
            vScroll = 0f,
            actionMasked = MotionEvent.ACTION_MOVE,
            actionButton = 0,
            buttonState = 0,
            isPointerCaptureActive = true
        )

        // With smoothing=0.50, first step moves ~50% (+17.5x, +7.5y) rather than losing the rest
        val firstAim = host.emittedEvents.last().pointers.first {
            it.id == PointerStreamCoordinator.MOUSE_AIM_POINTER_ID
        }
        assertEquals(667.5f, firstAim.x, 0.05f)
        assertEquals(457.5f, firstAim.y, 0.05f)

        // Drain smooth tail ticks until full scaled target arrives
        repeat(12) {
            engine.drainSmoothAimTickForTest()
        }
        val finalAim = host.emittedEvents.last().pointers.first {
            it.id == PointerStreamCoordinator.MOUSE_AIM_POINTER_ID
        }
        assertEquals(685.0f, finalAim.x, 0.1f)
        assertEquals(465.0f, finalAim.y, 0.1f)
    }

    @Test
    fun fpsLookToAimPanHandoff_switchesCleanlyOnLmbAndKeepsJoystickIntact() {
        val host = RecordingVirtualPointerHost()
        val engine = newEngine(host)

        // Hold physical joystick 0 + virtual WASD 16 + move FPS Look 17
        host.injectPhysicalDown(id = 0, x = 140f, y = 700f, downTime = 900L)
        engine.onHostKeyEvent(KeyEvent.KEYCODE_W, isDown = true)
        engine.onHostCapturedMouseEvent(12f, 0f, 0f, MotionEvent.ACTION_MOVE, 0, 0, isPointerCaptureActive = true)
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.MOUSE_AIM_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))

        // Press LMB via ACTION_MOVE buttonState sync (simulating missed ACTION_BUTTON_PRESS) + drag upward
        host.emittedEvents.clear()
        engine.onHostCapturedMouseEvent(
            dx = 4f,
            dy = -20f,
            vScroll = 0f,
            actionMasked = MotionEvent.ACTION_MOVE,
            actionButton = 0,
            buttonState = MotionEvent.BUTTON_PRIMARY,
            isPointerCaptureActive = true
        )

        assertTrue("AimPan slot 18 must engage via buttonState sync", host.coordinator.isVirtualActive(PointerStreamCoordinator.AIM_PAN_POINTER_ID))
        assertFalse("FPS Look slot 17 hands off cleanly to AimPan slot 18", host.coordinator.isVirtualActive(PointerStreamCoordinator.MOUSE_AIM_POINTER_ID))
        assertTrue("WASD slot 16 must remain active", host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertTrue("Physical finger 0 must remain active", host.coordinator.activePhysicalIds().contains(0))

        val dragged = host.emittedEvents.last().pointers.first { it.id == PointerStreamCoordinator.AIM_PAN_POINTER_ID }
        assertEquals(854f, dragged.x, 0.05f)
        assertEquals(730f, dragged.y, 0.05f)

        // Continue dragging upward while firing -> moves AimPan, never cancels joystick
        engine.onHostCapturedMouseEvent(
            dx = 0f,
            dy = -25f,
            vScroll = 0f,
            actionMasked = MotionEvent.ACTION_MOVE,
            actionButton = 0,
            buttonState = MotionEvent.BUTTON_PRIMARY,
            isPointerCaptureActive = true
        )
        val draggedMore = host.emittedEvents.last().pointers.first { it.id == PointerStreamCoordinator.AIM_PAN_POINTER_ID }
        assertEquals(705f, draggedMore.y, 0.05f)

        // Release LMB -> AimPan lifts, WASD + physical joystick stay down
        engine.onHostCapturedMouseEvent(
            dx = 0f,
            dy = 0f,
            vScroll = 0f,
            actionMasked = MotionEvent.ACTION_HOVER_MOVE,
            actionButton = 0,
            buttonState = 0,
            isPointerCaptureActive = true
        )
        assertFalse(host.coordinator.isVirtualActive(PointerStreamCoordinator.AIM_PAN_POINTER_ID))
        assertTrue(host.coordinator.isVirtualActive(PointerStreamCoordinator.WASD_POINTER_ID))
        assertTrue(host.coordinator.activePhysicalIds().contains(0))
        assertTrue(host.emittedEvents.none { it.action == PointerStreamCoordinator.ACTION_UP || it.action == PointerStreamCoordinator.ACTION_CANCEL })
    }

    @Test
    fun syntheticEchoFilter_dropsAnyEventWithVirtualIdsDuringPhysicalSwipe() {
        val coordinator = PointerStreamCoordinator()
        // Finger 0 holds Macro Trigger, Finger 1 starts swiping screen at (600, 420) -> moves to (680, 410)
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_DOWN,
            actionIndex = 0,
            downTime = 1000L,
            deviceId = 7,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(PointerStreamCoordinator.fingerPointer(0, 820f, 650f))
        )
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_POINTER_DOWN,
            actionIndex = 1,
            downTime = 1000L,
            deviceId = 7,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(
                PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                PointerStreamCoordinator.fingerPointer(1, 680f, 410f)
            )
        )

        // Echoed synthetic ACTION_MOVE carrying stale Finger 1 (600, 420), ghost Finger 2, and Macro 15
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_MOVE,
            actionIndex = 0,
            downTime = 1000L,
            deviceId = 7,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(
                PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                PointerStreamCoordinator.fingerPointer(1, 600f, 420f),
                PointerStreamCoordinator.fingerPointer(2, 300f, 300f),
                PointerStreamCoordinator.fingerPointer(PointerStreamCoordinator.MACRO_POINTER_ID, 740f, 520f)
            )
        )

        // Assert stale echo was ignored: Finger 2 was not resurrected and Finger 1 kept latest position
        assertEquals(setOf(0, 1), coordinator.activePhysicalIds())
        val plan = coordinator.planUpsert(
            pointerId = PointerStreamCoordinator.MACRO_POINTER_ID,
            xPx = 740f,
            yPx = 520f,
            nowMs = 1020L,
            fallbackTouchDeviceId = 7
        ) as PointerStreamCoordinator.UpsertPlan.JoinOrDown
        val finger1 = plan.event.pointers.first { it.id == 1 }
        assertEquals(680f, finger1.x, 0.01f)
        assertEquals(410f, finger1.y, 0.01f)
    }

    @Test
    fun macroRepeatTap_concurrentWithTriggerHoldSwipeAndHudTap_liftsCleanlyWithoutBlocking() {
        val coordinator = PointerStreamCoordinator()

        // 1) Hold Trigger (Finger 0) + Swipe Camera (Finger 1)
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_DOWN,
            actionIndex = 0,
            downTime = 2000L,
            deviceId = 7,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(PointerStreamCoordinator.fingerPointer(0, 820f, 650f))
        )
        coordinator.onPhysicalEvent(
            actionMasked = PointerStreamCoordinator.ACTION_POINTER_DOWN,
            actionIndex = 1,
            downTime = 2000L,
            deviceId = 7,
            source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
            displayId = 0,
            eventPointers = listOf(
                PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                PointerStreamCoordinator.fingerPointer(1, 500f, 400f)
            )
        )

        var lastEventTime = 0L
        // 2) Run 4 tap-tap cycles on Macro (15) while Finger 1 swipes & Finger 2 taps+lifts a HUD button
        for (cycle in 0 until 4) {
            val baseT = 2010L + cycle * 40L
            // Finger 1 moves forward
            coordinator.onPhysicalEvent(
                actionMasked = PointerStreamCoordinator.ACTION_MOVE,
                actionIndex = 0,
                downTime = 2000L,
                deviceId = 7,
                source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
                displayId = 0,
                eventPointers = listOf(
                    PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                    PointerStreamCoordinator.fingerPointer(1, 500f + (cycle + 1) * 25f, 400f)
                )
            )
            if (cycle == 1) {
                // Finger 2 presses another HUD button simultaneously
                coordinator.onPhysicalEvent(
                    actionMasked = PointerStreamCoordinator.ACTION_POINTER_DOWN,
                    actionIndex = 2,
                    downTime = 2000L,
                    deviceId = 7,
                    source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
                    displayId = 0,
                    eventPointers = listOf(
                        PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                        PointerStreamCoordinator.fingerPointer(1, 550f, 400f),
                        PointerStreamCoordinator.fingerPointer(2, 220f, 700f)
                    )
                )
            }

            // Macro Target DOWN (must be ACTION_POINTER_DOWN, never solo ACTION_DOWN)
            val downPlan = coordinator.planUpsert(
                pointerId = PointerStreamCoordinator.MACRO_POINTER_ID,
                xPx = 740f,
                yPx = 520f,
                nowMs = baseT,
                fallbackTouchDeviceId = 7
            ) as PointerStreamCoordinator.UpsertPlan.JoinOrDown
            assertFalse(downPlan.isFreshDown)
            assertEquals(PointerStreamCoordinator.ACTION_POINTER_DOWN, downPlan.event.action and 0xFF)
            assertTrue(downPlan.event.eventTime >= lastEventTime)
            lastEventTime = downPlan.event.eventTime
            coordinator.commitUpsert(downPlan)
            assertTrue(coordinator.isVirtualActive(PointerStreamCoordinator.MACRO_POINTER_ID))

            if (cycle == 2) {
                // Finger 2 lifts HUD button while Macro tap is active
                coordinator.onPhysicalEvent(
                    actionMasked = PointerStreamCoordinator.ACTION_POINTER_UP,
                    actionIndex = 2,
                    downTime = 2000L,
                    deviceId = 7,
                    source = PointerStreamCoordinator.SOURCE_TOUCHSCREEN,
                    displayId = 0,
                    eventPointers = listOf(
                        PointerStreamCoordinator.fingerPointer(0, 820f, 650f),
                        PointerStreamCoordinator.fingerPointer(1, 575f, 400f),
                        PointerStreamCoordinator.fingerPointer(2, 220f, 700f)
                    )
                )
            }

            // Macro Target UP via planRemove + commitRemove (must be ACTION_POINTER_UP, never stuck down)
            val upPlan = coordinator.planRemove(
                pointerId = PointerStreamCoordinator.MACRO_POINTER_ID,
                nowMs = baseT + 14L,
                fallbackTouchDeviceId = 7
            )
            assertNotNull(upPlan)
            assertEquals(PointerStreamCoordinator.ACTION_POINTER_UP, upPlan!!.action and 0xFF)
            assertTrue(upPlan.eventTime >= lastEventTime)
            lastEventTime = upPlan.eventTime
            assertTrue(upPlan.pointers.any { it.id == 0 })
            assertTrue(upPlan.pointers.any { it.id == 1 })
            if (cycle >= 2) {
                assertFalse("Lifted HUD Finger 2 must not remain in Macro UP stream", upPlan.pointers.any { it.id == 2 })
            }
            coordinator.commitRemove(PointerStreamCoordinator.MACRO_POINTER_ID)
            assertFalse("Macro pointer 15 must NEVER stay held after tap", coordinator.isVirtualActive(PointerStreamCoordinator.MACRO_POINTER_ID))
        }

        assertEquals(setOf(0, 1), coordinator.activePhysicalIds())
    }
}

