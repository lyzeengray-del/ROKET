package com.example

import android.content.Context
import android.view.KeyEvent
import androidx.test.core.app.ApplicationProvider
import com.example.model.KeyTriggerBehavior
import com.example.model.KeyboardMouseConfig
import com.example.model.KeyboardMouseJsonCodec
import com.example.model.KeyboardMouseNode
import com.example.model.KeymapActionType
import com.example.model.MouseTweaksConfig
import com.example.shizuku.LvngKeyCodes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("LVNG SPACE", appName)
  }

  @Test
  fun `keyboardMouseJsonCodec preserves nodes coordinates and mouse tweaks`() {
    val original = KeyboardMouseConfig(
      nodes = listOf(
        KeyboardMouseNode(
          id = "kb_wasd",
          name = "WASD",
          type = KeymapActionType.WASD_JOYSTICK,
          keyCode = 0,
          xFraction = 0.21f,
          yFraction = 0.73f,
          radiusFraction = 0.11f
        ),
        KeyboardMouseNode(
          id = "kb_fire",
          name = "SHOOT",
          type = KeymapActionType.KEY_TAP,
          keyCode = LvngKeyCodes.MOUSE_LEFT,
          xFraction = 0.87f,
          yFraction = 0.69f,
          triggerBehavior = KeyTriggerBehavior.TOGGLE,
          holdTapDurationMs = 75
        )
      ),
      tweaks = MouseTweaksConfig(
        sensitivityX = 2.15f,
        sensitivityY = 1.85f,
        acceleration = 1.25f,
        smoothing = 0.35f,
        deadzonePx = 0.8f,
        invertY = true,
        aimResetRadiusFraction = 0.34f,
        cursorToggleKeyCode = KeyEvent.KEYCODE_TAB,
        autoLockAimOnEnable = false,
        showKeyHintsOverlay = true,
        overlayOpacity = 0.65f
      ),
      isActive = true
    )

    val encoded = KeyboardMouseJsonCodec.encodeToString(original)
    val decoded = KeyboardMouseJsonCodec.decode(encoded)

    assertTrue(decoded.isActive)
    assertEquals(2, decoded.nodes.size)
    assertEquals(0.21f, decoded.nodes[0].xFraction, 0.001f)
    assertEquals(0.73f, decoded.nodes[0].yFraction, 0.001f)
    assertEquals(LvngKeyCodes.MOUSE_LEFT, decoded.nodes[1].keyCode)
    assertEquals(KeyTriggerBehavior.TOGGLE, decoded.nodes[1].triggerBehavior)
    assertEquals(2.15f, decoded.tweaks.sensitivityX, 0.001f)
    assertEquals(1.25f, decoded.tweaks.acceleration, 0.001f)
    assertEquals(true, decoded.tweaks.invertY)
    assertEquals(KeyEvent.KEYCODE_TAB, decoded.tweaks.cursorToggleKeyCode)
  }
}

